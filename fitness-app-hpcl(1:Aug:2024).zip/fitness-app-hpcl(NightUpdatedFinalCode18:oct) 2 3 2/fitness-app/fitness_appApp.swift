//
//  fitness_appApp.swift
//  fitness-app
//
//  Created by Babu Lal on 13/12/22.
//

import SwiftUI

@main
struct fitness_appApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) var delegate
    var body: some Scene {
        WindowGroup {
            LoginView()
        }
    }
}
