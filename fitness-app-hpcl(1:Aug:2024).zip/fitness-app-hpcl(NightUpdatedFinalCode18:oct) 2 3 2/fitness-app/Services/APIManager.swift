//
//  APIManager.swift
//  fitness-app
//
//  Created by Babu Lal on 18/12/22.
//

import Foundation
import Alamofire
import SwiftUI

public typealias FailureMessage = String

/**
 API Manager is a singleton class for handle all network call.
 */
public class APIManager {
    // A Singleton instance
    public static let shared = APIManager()
    
    func jsonToData(json: Any) -> Data? {
        do {
            return try JSONSerialization.data(withJSONObject: json, options: JSONSerialization.WritingOptions.prettyPrinted)
        } catch let myJSONError {
            print(myJSONError)
        }
        return nil;
    }
    func callAPI(serverURL: URL?, queryItems: [URLQueryItem]? = nil, method: HTTPMethod = .get, headers: HTTPHeaders? = nil, parameters: Parameters? = nil, success: @escaping ((AFDataResponse<Data>) -> Void), failure: @escaping ((FailureMessage) -> Void)) {
        
        //print("url : \(String(describing: serverURL))")
        //print("request : \(String(describing: parameters))")
       // print("headers : \(String(describing: headers))")
        
        guard var url = URLComponents(string: "\(serverURL!)") else {
            failure("Invalid URL")
            print("SERVER URL",serverURL)
            return
        }
        
        if let queryItems = queryItems {
            url.queryItems = queryItems
        }
        
        
        
        
        
        
       /* Network request
                AF.request(url, method: method, parameters: params, encoding: JSONEncoding.default, headers: headers)
                    .authenticate(with: credential)
        
                    .responseData { response in
                        switch response.result {
                        case .success:
                            print("response : \(String(describing: response.response))")
                            success(response)
                        case let .failure(error):
                            print("failure : \(error.localizedDescription)")
                            failure(error.localizedDescription)
                        }
                    } */
        

        
     
        AF.upload(multipartFormData: { multipartFormData in
           // multipartFormData.append(Data(String(describing: parameters).utf8), withName: "")
           // multipartFormData.append(Data(String(describing: parameters!).utf8), withName: "")
            multipartFormData.append(self.jsonToData(json: parameters!)!, withName: "")
            print("ParametersFingerAuth",parameters)
        }, to: url, method: method, headers: headers)
    
        .responseData { response in
            
            self.processResponse(response: response) { successResponse in
                print("successResponse \(successResponse)")
                success(successResponse)
            } failure: { FailureMessage in
                failure(FailureMessage)
            }

        }
        
    }
    
    
    func callAPIJson(serverURL: URL?, queryItems: [URLQueryItem]? = nil, method: HTTPMethod = .get, headers: HTTPHeaders? = nil, parameters: Parameters? = nil, success: @escaping ((AFDataResponse<Data>) -> Void), failure: @escaping ((FailureMessage) -> Void)) {
        
       // print("url : \(String(describing: serverURL))")
        //print("request : \(String(describing: parameters))")
       // print("headers : \(String(describing: headers))")
        
        guard var url = URLComponents(string: "\(serverURL!)") else {
            failure("Invalid URL")
            return
        }
        
        if let queryItems = queryItems {
            url.queryItems = queryItems
        }
        
        
       // Network request
                AF.request(url, method: method, parameters: parameters, encoding: JSONEncoding.default, headers: headers)
                   
        
                    .responseData { response in
                        
                        self.processResponse(response: response) { successResponse in
                           
                            success(successResponse)
                        } failure: { FailureMessage in
                            failure(FailureMessage)
                        }
                      /*  switch response.result {
                        case .success:
                            print("response : \(String(describing: response.response))")
                            success(response)
                        case let .failure(error):
                            print("failure : \(error.localizedDescription)")
                            failure(error.localizedDescription)
                        }  */
                    }

     
      /*  AF.upload(multipartFormData: { multipartFormData in
           // multipartFormData.append(Data(String(describing: parameters).utf8), withName: "")
           // multipartFormData.append(Data(String(describing: parameters!).utf8), withName: "")
            multipartFormData.append(self.jsonToData(json: parameters!)!, withName: "")

        }, to: url, method: method, headers: headers)
      
        .responseData { response in
            
            self.processResponse(response: response) { successResponse in
                print("successResponse \(successResponse)")
                success(successResponse)
            } failure: { FailureMessage in
                failure(FailureMessage)
            }

        }  */
        
    }
    
    func callAPIArray(serverURL: URL?, queryItems: [URLQueryItem]? = nil, method: HTTPMethod = .get, headers: HTTPHeaders? = nil, parameters: Any, success: @escaping ((AFDataResponse<Data>) -> Void), failure: @escaping ((FailureMessage) -> Void)) {
        
        //print("url : \(serverURL)")
        //print("request : \(parameters)")
        //print("headers : \(headers)")
        
        guard var url = URLComponents(string: "\(serverURL!)") else {
            failure("Invalid URL")
            return
        }
        
        if let queryItems = queryItems {
            url.queryItems = queryItems
        }
        
        AF.upload(multipartFormData: { multipartFormData in
          
            multipartFormData.append(self.jsonToData(json: parameters)!, withName: "")

        }, to: url, method: method, headers: headers)
      
        .responseData { response in
            
            self.processResponse(response: response) { successResponse in
                success(successResponse)
            } failure: { FailureMessage in
                failure(FailureMessage)
            }
        }
        
    }
    
    func processResponse(response : AFDataResponse<Data>, success: @escaping ((AFDataResponse<Data>) -> Void), failure: @escaping ((FailureMessage) -> Void)){
        
        
        switch response.result{
        case .success:
            //print("response : \(String(describing: response.response))")
            //print("response : \(String(describing: response.response?.statusCode))")
            
           // success(response)
            
           

            
            switch response.response?.statusCode {
            case 200,201,202,203, 204:
                success(response)
            case 400:
                //failure("Bad Request, Please check entered data and try again")
                processErrorMessage(message: "Bad Request, Please check entered data and try again", response: response) { FailureMessage in
                    failure(FailureMessage)
                }
            case 401:
                //failure("Unauthorized")
                processErrorMessage(message: "Unauthorized", response: response) { FailureMessage in
                    failure(FailureMessage)
                }
            case 402,403:
                //failure("Forbidden")
                processErrorMessage(message: "Forbidden", response: response) { FailureMessage in
                    failure(FailureMessage)
                }
            case 404:
                //failure("Not Found")
                processErrorMessage(message: "Not Found", response: response) { FailureMessage in
                    failure(FailureMessage)
                }
            case 500:
                failure("Internal Server Error")
               
            default:
                failure("Unable to get response from server")
            }
            
            
        case let .failure(error):
            //print("failure : \(error.localizedDescription)")
            failure(error.localizedDescription)
        }
    }
    
   func processErrorMessage(message : String,response : AFDataResponse<Data>, failure: @escaping ((FailureMessage) -> Void)){
        
       do {
           if let data = response.data {
               let dataResponse = try JSONDecoder().decode(FailureResponseModel.self, from: data)
               //success(dataResponse)
               //print("failure_400 \(dataResponse.status)")
               if(dataResponse.status != nil ){
                  
                   failure(dataResponse.status!)
               }
           }
       } catch {
           failure(message)
       }
    }
}


