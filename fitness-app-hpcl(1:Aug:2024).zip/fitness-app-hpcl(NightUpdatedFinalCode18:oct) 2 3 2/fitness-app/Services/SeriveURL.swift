//
//  SeriveURL.swift
//  fitness-app
//
//  Created by Babu Lal on 18/12/22.
//

import Foundation
struct SeriveURL {
    enum Path {

        case login
        case validateOTP
       
        case validateToken
        case lastUpdatedDate
        case fitnessDataPush
        case updateGoal
        case updatePreference
        case appStoreVersionCheck
        
                
        fileprivate var components: String {
            switch self {
            case .login:
                return "fitnessMobileNoValidate"
            case .validateOTP:
                return "fitnessUserOTPValidate"
           
            case .validateToken:
                // // return "verifyFingerprintNew"
                return "verifyFingerprintNewv2"
            case .lastUpdatedDate:
                return "exsistingDate"
            case .fitnessDataPush:
                return "fitnessData"
            case .updateGoal:
                return "updateGoal"
            case .updatePreference:
                return "userPreference"
            case .appStoreVersionCheck:
                return "bundleId=com.hpcl.fitness-app"
            }
        }
    }
    private let path: Path
    
    private var baseURL: String {
                
       // String(format: "%@", Bundle.main.object(forInfoDictionaryKey: "BASE_URL") as! String)
        String(format: "%@", EnvironmentManager().baseUrl)
    }
    
    private var baseURLAppStoreVersion: String {
        
       String(format: "%@", Bundle.main.object(forInfoDictionaryKey: "BASE_URL_APP_STORE_VERSION") as! String)
        //String(format: "%@", EnvironmentManager().baseUrl)
    }
    
    
    //BASE_URL_APP_STORE_VERSION
    
    init(path: Path) {
        self.path = path
    }
    
    var url: URL {
        let string = "https://\(baseURL)/\(path.components)"
        guard let url = URL(string: string) else { fatalError("SeriveURL conversion to URL failed unexpectedly") }
        return url
    }
    
    //This urlfingerprint is added as per pundarik sir said on 10th oct 2023"
    var urlfingerprint: URL {
        let string = "https://lubesws.hpcl.co.in/MobileOcrWebService//rest/FitnessLogin/verifyFingerprintNewv2"
        guard let url = URL(string: string) else { fatalError("SeriveURL conversion to URL failed unexpectedly") }
        return url
    }

    
    var urlAppStoreVersionCheck: URL {
        let string = "https://\(baseURLAppStoreVersion)?\(path.components)"
        guard let url = URL(string: string) else { fatalError("SeriveURL conversion to URL failed unexpectedly") }
        print("STRING12",string)
        print("STRING22",url)
        return url
    }
}
