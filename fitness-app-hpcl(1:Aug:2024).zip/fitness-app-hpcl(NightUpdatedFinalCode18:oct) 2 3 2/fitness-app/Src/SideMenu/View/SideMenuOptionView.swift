//
//  SideMenuOptionView.swift
//  SideMenu
//
//  Created by Babu Lal Choudhary on 27/03/22.
//

import SwiftUI

struct SideMenuOptionView: View {
    let viewModel : SideMenuViewModel
    
    var body: some View {

        if(viewModel.isVisible){
            HStack(spacing : CGFloat.theme.largeSpacing){
                            
                Image(systemName: viewModel.imageName).frame(width: 24.0, height: 24.0)
                Text(LocalizedStringKey(viewModel.title)).font(Font.theme.body)
                Spacer()
                
            }.padding(CGFloat.theme.smallSpacing)
                .foregroundColor(.white)
        }
            //.disabled(viewModel.isVisible)
    }
}


