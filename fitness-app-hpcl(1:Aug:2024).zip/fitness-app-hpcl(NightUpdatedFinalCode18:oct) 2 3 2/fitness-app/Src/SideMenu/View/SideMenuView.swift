//
//  SideMenuView.swift
//  SideMenu
//
//  Created by Babu Lal Choudhary on 27/03/22.
//

import SwiftUI

struct SideMenuView: View {
    @Binding var isShowing : Bool
    @State var isLogout: Bool = false
    @ObservedObject var viewModel = HomeViewModel()
    @State  var isStepClick = false
    @State  var isDistanceClick = false
    @State  var isCaloriesClick = false
//**Here in this screen leaderboard and last seven steps content is sir told to commented on 13/jul/2023 **//
    var body: some View {
        ZStack(){
            LinearGradient(gradient: Gradient(colors: [Color.theme.brandPrimary, Color.theme.brandSecondary]), startPoint: .top, endPoint: .bottom).ignoresSafeArea()
            
            VStack(){
                //Header
                SideMenuHeaderView(isShowing: $isShowing)
                
                ForEach(SideMenuViewModel.allCases, id : \.self) { option in
                    //SideMenuOptionView(viewModel: option)
                    
                    NavigationLink {
                        
                        if(option == SideMenuViewModel.setGoal){
                            SetGoalView()
                        } else if(option == SideMenuViewModel.setPreferences){
                            
                           // UserDefaults.standard.isPreferences == true ? SetPreferencesView() : EmptyView()
                            SetPreferencesView()
                        }
                       
                        else if(option == SideMenuViewModel.pme){

                            //WebUIView(viewModel: WebViewModel(url: "https://medclaim.hpcl.co.in/medclaim/pme.jsp?c=675g19kGyol8eZQ/vqH2SQ=="))
                            
                           //c=675g19kGyol8eZQ/vqH2SQ==
                            
                            // Get the user-specific value from UserDefaults
                                    let empNo = UserDefaults.standard.empNo ?? ""
                                    
                                    // Construct the URL string by appending empNo
                                    let urlString = "http://medclaim.hpcl.co.in/medclaim/pme.jsp?c=" + empNo
                        
                            WebUIView(viewModel: WebViewModel(url:urlString)).frame(width: 400, height: 800)
                                .toolbar{
                                CustomToolBar(title : "Health Index", transparency: false)
                            }

                        }
                        else if(option == SideMenuViewModel.leaderboard){
                            //print("LEADERBOARD")
                            //WebUIView(viewModel: WebViewModel(url:f "https://medclaim.hpcl.co.in/medclaim/pme.jsp?c=675g19kGyol8eZQ/vqH2SQ=="))
                           
                            WebUIView(viewModel: WebViewModel(url: "http://lubesws.hpcl.co.in/MobileOcrWebService/HealthApp/leaderBoardTop10enc_new.jsp?emailid=" + (UserDefaults.standard.email ?? "")))
                          //  Text(UserDefaults.standard.email!)

                            
                        }
//                        else if(option == SideMenuViewModel.lastsevendaysstepcount){
//
//                        StepscountView()
//                           // ReportView(viewModel: ReportViewModel())
//
//                            //                            if(viewModel.isLoading == false){
//                            //                                GraphicalView(energyBurnedToday: viewModel.energyBurnedToday, heartRate:viewModel.heartRate, walkingDistance: viewModel.walkingDistance, dayStepCount: viewModel.dayStepCount, percentageDayStepCount:viewModel.percentageDayStepCount, onStepClick: self.onStepClick, onDistanceClick: self.onDistanceClick,onCaloriesClick: self.onCaloriesClick)
//                            //                                BarChartView(data : viewModel.stepCountData, dataType: .steps)
//                            //                            }else {
//                            //                                ProgressView("loading")
//                            //                            }
//                            //                            }
//                            //
//                            //                            }
//
//                            //                        else if(option == SideMenuViewModel.logout){
//                            //
//                            //                           //UserDefaults.standard.reset();
//                            //
//                            //                            LoginView().navigationBarBackButtonHidden(true)
//                            //                        }
//
//                            //                        else {
//                            //                            DashboardView()
//                            //                        }
//                        }
                        
                    } label: {
                        SideMenuOptionView(viewModel: option)
                    }
                    
                }
                Button{
                     UserDefaults.standard.reset();
                     isLogout = true
                    
                }label: {
                    HStack(spacing : CGFloat.theme.largeSpacing){
                                    
                        Image(systemName: "arrow.left.square").frame(width: 24.0, height: 24.0)
                        Text(LocalizedStringKey("logout")).font(Font.theme.body)
                        
                        Spacer()
                        
                    }.padding(CGFloat.theme.smallSpacing)
                        .foregroundColor(.white)

                }
                Spacer()
                }.navigationDestination(isPresented: $isLogout) {
               
                LoginView().navigationBarBackButtonHidden(true)
            }
        }.navigationBarHidden(true)
    }
    
    func onStepClick() {
       
        isStepClick = true;
           
    }
    
    func onDistanceClick() {
       
        isDistanceClick = true;
           
    }
    
    func onCaloriesClick() {
       
        isCaloriesClick = true;
           
    }
}

struct SideMenuView_Previews: PreviewProvider {
    static var previews: some View {
        SideMenuView(isShowing: .constant(true))
    }
}
