//
//  SideMenuHeaderView.swift
//  SideMenu
//
//  Created by Babu Lal Choudhary on 27/03/22.
//

import SwiftUI

struct SideMenuHeaderView: View {
    
    @Binding var isShowing : Bool
    var body: some View {
        ZStack(alignment: .topTrailing) {
            
            Button {
                
                withAnimation(.spring()){
                    isShowing.toggle()
                }
              
            } label: {
                Image(systemName: "xmark").frame(width: 48, height: 48 ).foregroundColor(.white).padding()
            }
            
          

            
            VStack(alignment: .leading){
                
                HStack{
                    Image("logo").resizable().aspectRatio(contentMode: .fit).frame(height: 48.0)
                        //.frame(width: 48.0, height: 48.0, alignment: .center)
                        //.scaledToFill()
                        //.clipped().frame(width: 64.0, height: 64.0, alignment: .center).clipShape(Circle())
                    
                    Text("appName").font(Font.theme.navTitle)

                }.padding(.bottom, CGFloat.theme.smallSpacing)
              
                Text("\(UserDefaults.standard.name ?? "")").font(Font.theme.navTitle).padding(.bottom, CGFloat.theme.extraSmallSpacing)
                Text("\(UserDefaults.standard.email?.lowercased() ?? "")").font(Font.theme.body).padding(.bottom, CGFloat.theme.extraSmallSpacing)
                Text("\(UserDefaults.standard.mobile ?? "")").font(Font.theme.body).padding(.bottom, CGFloat.theme.mediumSpacing)
                
                HStack(spacing : 14){
//                    HStack(){
//                        Text("1254").bold()
//                        Text("Following")
//                    }
//                    HStack(){
//                        Text("607").bold()
//                        Text("Followers")
//                    }
                    Spacer()
                }

            }.padding().foregroundColor(.white)
        }
    }
}

struct SideMenuHeaderView_Previews: PreviewProvider {
    static var previews: some View {
        SideMenuHeaderView(isShowing: .constant(true))
    }
}
