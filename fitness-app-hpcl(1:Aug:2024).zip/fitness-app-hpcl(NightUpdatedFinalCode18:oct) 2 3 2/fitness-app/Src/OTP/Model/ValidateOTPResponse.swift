//
//  ValidateOTPResponse.swift
//  fitness-app
//
//  Created by Babu Lal on 20/12/22.
//

import Foundation
import Foundation


/*
 
 {"status": "Successfully Inserted/Updated into table.",
     "name": "Manohar",
             "emailid": "manideepgundeti@gmail.com",
     "token": "40479c9-cc1e-4df6-9",
     "preference": "Y",
     "heart_point": "N",
     "calorie": "N",
     "distance": "N",
     "move_minute": "N" }
 */
struct ValidateOTPResponse: Codable {
    var status: String?;
    var name: String?;
    var emailid: String?;
    var token: String?;
    var preference: String?;
    var heart_point: String?;
    var calorie: String?;
    var distance: String?;
    var move_minute: String?;
    var stepGoal: String?;
    var heartGoal: String?;
    var empNo: String?;
    var encrypted_empNo: String?;
    var pmeStatus: String?;
    
}


