//
//  WebUIView.swift
//  fitness-app
//
//  Created by Babu Lal on 04/01/23.
//

import SwiftUI

struct WebUIView: View {
   // @ObservedObject var viewModel = WebViewModel(url: "https://medclaim.hpcl.co.in/medclaim/pme.jsp?c=675g19kGyol8eZQ/vqH2SQ==")
    @ObservedObject var viewModel : WebViewModel

       var body: some View {
           NavigationStack {
               ZStack {
                   WebViewContainer(webViewModel: viewModel)
                   if viewModel.isLoading {
                       //Spinner().frame(height: 30)
                       ProgressView("loading")
                   }
               }
//               .toolbar{
//                   CustomToolBar(title : "pem", transparency: false)
//               }
//               .toolbar{
//                   CustomToolBar(title: "leaderboard",transparency: false)
//               }
//               .toolbar{
//                   CustomToolBar(title: "lastsevendaysstepcount",transparency: false)
//               }
            /*   .navigationBarTitle(Text(viewModel.title), displayMode: .inline)
               .navigationBarItems(leading: Button(action: {
                   viewModel.shouldGoBack.toggle()
               }, label: {
                   if viewModel.canGoBack {
                       Image(systemName: "arrow.left")
                           .frame(width: 44, height: 44, alignment: .center)
                           .foregroundColor(.black)
                   } else {
                       EmptyView()
                           .frame(width: 0, height: 0, alignment: .center)
                   }
               })
               ) */
           }
       }
}

