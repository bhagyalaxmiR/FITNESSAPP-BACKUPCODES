//
//  WebViewModel.swift
//  fitness-app
//
//  Created by Babu Lal on 04/01/23.
//

import Foundation
class WebViewModel: ObservableObject {
    @Published var isLoading: Bool = false
    @Published var canGoBack: Bool = false
    @Published var shouldGoBack: Bool = false
    @Published var title: String = ""
    
    var url: String
    
    init(url: String) {
        self.url = url
        //print("pmeDataUrl \(self.url)")
    }
}
