//
//  LoginViewModel.swift
//  fitness-app
//
//  Created by Babu Lal on 18/12/22.
//

import Foundation
import SwiftUI
import LocalAuthentication


class LoginViewModel: ObservableObject {
    
    @Published var mobileNumber : String = ""
    
    @Published var mobileNumberErrorMessage = ""
    @Published var isLoading = false
    @Published  var errorMessage = ""
    @Published  var isShowingAlert = false
    
    @Published var isSuccess = false
    
    @Published var isValidMobileNumber = false
    
    @Published  var isTokenValid = false
        
    @Published  var createLoginResponse : CreateLoginResponse?
    
    @Published var isUnlocked = false
    @Published var isLoadingToken = false

    
    func getLocalData(){
       
        //print("loginStatus \(UserDefaults.standard.loginStatus)")
        //UserDefaults.standard.reset()
       // print("App version: \(getAppInfo())")
        //print("App version: \(Constants.appVersion)")
        
        if(UserDefaults.standard.loginStatus == true){
            DispatchQueue.main.async {
                self.isLoadingToken = true;
            }
            
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 5)
            {
                print("pushNotificationFirebaseToken \(UserDefaults.standard.pushNotificationFirebaseToken)")
                self.validateToken(request: ValidateTokenRequest(emailid: UserDefaults.standard.email, token: UserDefaults.standard.token, mobileNo: UserDefaults.standard.mobile,app_type: Constants.appType, app_version: Constants.appVersion,firebase: UserDefaults.standard.pushNotificationFirebaseToken))
                
            }
        }
    }
    

    
    func biometricAuthenticate() {
        let context = LAContext()
        var error: NSError?
                
        // check whether biometric authentication is possible
        if context.canEvaluatePolicy(.deviceOwnerAuthentication, error: &error) {
            // it's possible, so go ahead and use it
            let reason = "We need to unlock your data."
            context.evaluatePolicy(.deviceOwnerAuthentication, localizedReason: reason) { success, authenticationError in
                // authentication has now completed
                if success {
                    // authenticated successfully
                    
                    DispatchQueue.main.async {
                        self.isUnlocked = true;
                        Text("kwjkwdkwjndKK")
                        //print("isUnlocked_0 \(self.isUnlocked)")
                    }
                } else {
                  
                    
                    DispatchQueue.main.async {
                        self.isUnlocked = false;
                        //print("isUnlocked_1 \(self.isUnlocked)")
                    }
                }
            }
        } else {
            
            DispatchQueue.main.async {
                self.isUnlocked = false;
                self.errorMessage = "biometricNotAvailable";
                Text("jsdcjsdghjcwsj")
                self.isShowingAlert = true;
                self.isLoading = false;
            }
        }
    }
    
    
    func isMobileNumberChanged(value : String)  {
        
        mobileNumber = value;
        
        if value.isValidPhone() {
            mobileNumberErrorMessage =  ""
            isValidMobileNumber = true;
        } else {
            isValidMobileNumber = false;
            mobileNumberErrorMessage =  "invalidMobileNumber"
        }
    }
    
    func createLogin(request: CreateLoginRequest) {
        DispatchQueue.main.async {
            self.isLoading = true;
        }
        APIServices.shared.callCreateLogin(parameters: request.dictionary ?? [:]) { response in
            if let response = response {
                //print("success \(response)")
                
                DispatchQueue.main.async {
                    self.createLoginResponse = response;
                    self.isLoading = false;
                    self.isSuccess = true;
                    
                }
            }
        }
    failure: { error in
        //print("error \(error)")
        DispatchQueue.main.async {
            self.errorMessage = "\(error)";
            self.isShowingAlert = true;
            self.isLoading = false;
        }
    }
}
    
    func validateToken(request: ValidateTokenRequest) {
        
        APIServices.shared.callValidateToken(parameters: request.dictionary ?? [:]) { response in
            if let response = response {
                print("success \(response)")
               
                DispatchQueue.main.async {
                    UIPreferences.setPreference(token: response.token, preference: response.preference, heart_point: response.heart_point, calorie: response.calorie, distance: response.distance, move_minute: response.move_minute, stepGoal: response.stepGoal, heartGoal: response.heartGoal)
                                        
//                    UserDefaults.standard.token = response.token;
//                    UserDefaults.standard.isPreferences = response.preference == "Y" ? true : false;
//                   // UserDefaults.standard.isPreferences = true;
//                    UserDefaults.standard.isHeartPoint = response.heart_point == "Y" ? true : false;
//                    UserDefaults.standard.isCalories = response.calorie == "Y" ? true : false;
//                    UserDefaults.standard.isDistance = response.distance == "Y" ? true : false;
//                    UserDefaults.standard.isMoveMinute = response.move_minute == "Y" ? true : false;
//                    UserDefaults.standard.stepsADay = response.stepGoal;
//                    UserDefaults.standard.heartPointADay = response.heartGoal;
                    
                    self.isLoadingToken = false;
                    self.isTokenValid = true;
                    
                }
            }
        }
    failure: { error in
        //print("error \(error)")
        DispatchQueue.main.async {
            self.errorMessage = "\(error)";
            self.isShowingAlert = true;
            self.isLoadingToken = false;
        }
    }
    }
    
}

