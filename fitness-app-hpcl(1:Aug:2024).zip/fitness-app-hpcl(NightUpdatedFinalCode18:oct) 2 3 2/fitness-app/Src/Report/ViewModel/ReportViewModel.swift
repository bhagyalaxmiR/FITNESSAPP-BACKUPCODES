//
//  ReportViewModel.swift
//  fitness-app
//
//  Created by Babu Lal on 29/12/22.
//

import Foundation
import Foundation
import HomeKit
import SwiftUI
import HealthKit
import Alamofire

class ReportViewModel: ObservableObject {
    
    @Published var isLoading = false;
    @Published var isSuccess = false;
    
    @Published var data: [[Date: Double]] = []
    
    @Published var days: [Date] = []
    
    @Published  var errorMessage = ""
    @Published  var isShowingAlert = false
    
    @Published var dataType : DataType = .steps
    @Published  var title = ""
   // let dataType: HKSampleTypeIdentifier

//    let dataType: HealthDataType
//       let title: String
   @Published  var isManualData: Bool // Define isManualData here
    
//       // Other properties and methods...
//       init(dataType: HealthDataType, title: String, isManualData: Bool) {
//           self.dataType = dataType
//           self.title = title
//           self.isManualData = isManualData // Initialize isManualData here
//       }
    
    init(dataType: DataType, title : String,isManualData : Bool) {
            self.dataType = dataType
        self.title = title
        self.isManualData = isManualData
        }
    
    func onChangeDate(){
        //print("days \(self.days)");
        if(self.days.count > 0){
            getHealthData()
        }else {
            guard let firstWeek = Calendar(identifier: .gregorian).dateInterval(of: .weekOfMonth, for: Date()),
                    let lastWeek = Calendar(identifier: .gregorian).dateInterval(of: .weekOfMonth, for: firstWeek.end - 1)
            else {
                return;
            }
            let dateInterval = DateInterval(start: firstWeek.start, end: lastWeek.end)
            self.days = Calendar(identifier: .gregorian).generateDays(for: dateInterval);
            getHealthData();
        }
    }
    
    // Fetch HealthKit data
      func fetchData() {
          // Create a predicate to filter out manually entered data
          var predicate: NSPredicate?
          if !isManualData {
              predicate = NSPredicate(format: "metadata.%K != YES", HKMetadataKeyWasUserEntered)
          }
          
          let sortDescriptor = NSSortDescriptor(key: HKSampleSortIdentifierStartDate, ascending: true)
          
         // let sampleType = dataType.sampleType // This will give you the HKSampleType for steps
          
          let healthStore = HKHealthStore()
          guard let sampleType = dataType.sampleType else {
                      // Handle unsupported data type
                      return
                  }

          let query = HKSampleQuery(
                    sampleType: sampleType,
                    predicate: predicate,
                    limit: Int(HKObjectQueryNoLimit),
                    sortDescriptors: [sortDescriptor]
                ){ (query, samples, error) in
                    // Handle fetched data here
                }
//               let query = HKSampleQuery(
//                sampleType: dataType.sampleType,
//                   predicate: predicate,
//                   limit: Int(HKObjectQueryNoLimit), // You can set a limit if needed
//                   sortDescriptors: [sortDescriptor]
//               ) { (query, samples, error) in
//                   // Handle fetched data here
//               }
               healthStore.execute(query)
          // Execute the query
      }

    func getHealthData() {
        
        DispatchQueue.main.async {
            self.isLoading = true;
        }
        
        GetHealthData().fetchDataForCustomDate(dataType: dataType, startDateValue: days[0], endDateValue: days[days.count-1]) { [weak self] (response, error) in
            
            guard (error == nil) else {
                DispatchQueue.main.async {
                    self!.isLoading = false;
                    self?.isShowingAlert = true;
                    self?.errorMessage = String(describing: error);
                }
                return
            }
            if let healthKitData = response {
                    DispatchQueue.main.async {
                    self?.data.removeAll()
                    self?.isLoading = false;
                    self?.data = healthKitData;
                    print("HEALTHdata \(String(describing: self?.data))")
                }
            }
        }
    }
}
