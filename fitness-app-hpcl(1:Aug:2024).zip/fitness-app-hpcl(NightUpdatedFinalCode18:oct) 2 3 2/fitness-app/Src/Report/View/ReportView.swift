//
//  ReportView.swift
//  fitness-app
//
//  Created by Babu Lal on 29/12/22.
//

import SwiftUI

struct ReportView: View {
    @ObservedObject var viewModel : ReportViewModel
    var body: some View {
        VStack{
            ScrollView{
                VStack{
                                        
                    CustomCalendarView(calendar: Calendar(identifier: .gregorian)) { days in
                                                
                        viewModel.days = days
                        viewModel.onChangeDate()
                    }
                    
                    if(viewModel.isLoading == false){
                                              
                        BarChartView(data : viewModel.data, dataType: viewModel.dataType)
                      
                        
                    }else {
                        ProgressView("loading")
                    }
                }
                .alert( viewModel.errorMessage, isPresented: $viewModel.isShowingAlert) {

                }
                
              
                
                .padding(CGFloat.theme.mediumSpacing)
            }
            .onAppear(perform: {
                
                viewModel.onChangeDate()
                
            }).toolbar{  CustomToolBar(title : viewModel.title, transparency: false)}
               
        }
        
        
    }
    
   
    
}



