//
//  LaunchSCreenViewModel.swift
//  fitness-app
//
//  Created by pundarik rajkhowa on 17/01/23.
//

import SwiftUI

struct LaunchSCreenViewModel: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
        NavigationStack{
            
        }
    }
}

struct LaunchSCreenViewModel_Previews: PreviewProvider {
    static var previews: some View {
        LaunchSCreenViewModel()
    }
}
