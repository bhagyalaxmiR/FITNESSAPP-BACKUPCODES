//
//  SetPreferencesViewModel.swift
//  fitness-app
//
//  Created by Babu Lal on 27/12/22.
//

import Foundation
import SwiftUI

class SetPreferencesViewModel: ObservableObject {
    
  
    @Published var isLoading = false
    @Published  var errorMessage = ""
    @Published  var isShowingAlert = false

    
    @Published var isSuccess = false
    
    @Published var isHeartPoints = false
    @Published var isCalorie = false
    @Published var isDistance = false
    @Published var isMoveMinute = false

    
    func setPreferenceApiCall() {
        
        
        DispatchQueue.main.async {
            self.isLoading = true;
        }
        
        let  request =  SetPreferencesRequest(emailid: UserDefaults.standard.email, token: UserDefaults.standard.token, heart_point: isHeartPoints == true ? "Y" : "N", calorie:isCalorie == true ? "Y" : "N", distance:isDistance == true ? "Y" : "N", move_minute: isMoveMinute == true ? "Y" : "N")
        
        APIServices.shared.setPreferences(parameters: request.dictionary ?? [:]) { response in
            if response != nil {
                print("success \(String(describing: response))")
                
                
                DispatchQueue.main.async {
                  
                    self.isLoading = false;
                    self.isSuccess = true;
                    
                   // UserDefaults.standard.heartPointADay = self.heartPointADay;
                    //UserDefaults.standard.stepsADay = self.stepsADay
                    
                    UserDefaults.standard.isHeartPoint = self.isHeartPoints
                    UserDefaults.standard.isCalories = self.isCalorie
                    UserDefaults.standard.isDistance = self.isDistance
                    UserDefaults.standard.isMoveMinute = self.isMoveMinute
                    
                    self.errorMessage = "updatedSuccessfully"
                    self.isShowingAlert = true;
                    
                    
                }
            }
        }
    failure: { error in
        
        print("error \(error)")
        
        DispatchQueue.main.async {
            self.errorMessage = "\(error)";
            self.isShowingAlert = true;
            self.isLoading = false;
        }
        
        
    }
    }
    
    func loadLocalData(){
         isHeartPoints = UserDefaults.standard.isHeartPoint
        isCalorie = UserDefaults.standard.isCalories
       isDistance = UserDefaults.standard.isDistance
       isMoveMinute = UserDefaults.standard.isMoveMinute
        
     

    }
    
}
