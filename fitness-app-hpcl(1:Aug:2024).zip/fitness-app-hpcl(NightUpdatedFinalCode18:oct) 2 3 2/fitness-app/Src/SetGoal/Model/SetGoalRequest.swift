//
//  SetGoalRequest.swift
//  fitness-app
//
//  Created by Babu Lal on 27/12/22.
//

import Foundation

struct SetGoalRequest: Codable {
    var emailid: String?
    var token: String?
    var stepGoal: String?
    var heartGoal: String?

}
