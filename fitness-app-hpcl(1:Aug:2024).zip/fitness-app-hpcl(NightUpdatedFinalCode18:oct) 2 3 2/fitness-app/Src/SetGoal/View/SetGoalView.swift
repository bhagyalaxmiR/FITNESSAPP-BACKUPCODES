//
//  SetGoalView.swift
//  fitness-app
//
//  Created by Babu Lal on 21/12/22.
//

import SwiftUI

struct SetGoalView: View {
    @ObservedObject var viewModel = SetGoalViewModel()
    
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>

    
    var body: some View {
        Form(){
            
            FloatingTextField(placeholder: LocalizedStringKey("stepsADay"), errorMessage: viewModel.stepsADayError,  isSecureTextEntry: false,  text: $viewModel.stepsADay, keyboardType: UIKeyboardType.numberPad) { value in
                
                viewModel.isStepADayChange(value: value)
                
            }.padding([.top], CGFloat.theme.mediumSpacing)
            
            /* FloatingTextField(placeholder: LocalizedStringKey("heartsPointsADay"), errorMessage: viewModel.heartPointADayError,  isSecureTextEntry: false,  text: $viewModel.heartPointADay, keyboardType: UIKeyboardType.numberPad) { value in
                
                viewModel.isHeartPointADayChange(value: value)
                
            }.padding([.top], CGFloat.theme.mediumSpacing) */
            
            if  viewModel.isLoading == false  {
                
                Button("submit") {
                    
                    //viewModel.isSubmitChange()
                    viewModel.setGoalApiCall(request: SetGoalRequest(emailid:UserDefaults.standard.email,token: UserDefaults.standard.token,stepGoal: viewModel.stepsADay, heartGoal: viewModel.heartPointADay))
                    
                }.buttonStyle(CustomButtonStyle()).disabled(!viewModel.isStepsADayValid)
                    //.disabled(!viewModel.isHeartPointADayValid)
                    .padding([.top,.bottom], CGFloat.theme.mediumSpacing)
                
                
            }else {
                
                ProgressView("loading")
            }
            
          
            
        }
        .alert( LocalizedStringKey(viewModel.errorMessage), isPresented: $viewModel.isShowingAlert) {
            
        }.toolbar{
            CustomToolBar(title : "setActivityGoals", transparency: false)
        }.onAppear{
            viewModel.setDefaultData()
        }
    }
}

struct SetGoalView_Previews: PreviewProvider {
    static var previews: some View {
        SetGoalView()
    }
}
