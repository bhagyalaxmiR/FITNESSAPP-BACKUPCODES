//
//  LastUpdatedDateResponse.swift
//  fitness-app
//
//  Created by Babu Lal on 24/12/22.
//

import Foundation
struct LastUpdatedDateResponse: Codable {
    var Last_Date: String?
}
