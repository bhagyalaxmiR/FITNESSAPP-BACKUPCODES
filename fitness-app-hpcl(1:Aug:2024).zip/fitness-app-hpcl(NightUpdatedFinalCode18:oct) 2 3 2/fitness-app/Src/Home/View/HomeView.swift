//
//  HomeView.swift
//  fitness-app
//
//  Created by Babu Lal on 13/12/22.
//

import SwiftUI

//struct HomeView: View {
//
//
//    @ObservedObject var viewModel = HomeViewModel()
//    @State  var isStepClick = false
//    @State  var isDistanceClick = false
//    @State  var isCaloriesClick = false
//
//
//    var body: some View {
//
//        Form(){
//            NavigationStack{
//                VStack{
//                    if(viewModel.isLoading == false){
//                        GraphicalView(energyBurnedToday: viewModel.energyBurnedToday, heartRate:viewModel.heartRate, walkingDistance: viewModel.walkingDistance, dayStepCount: viewModel.dayStepCount, percentageDayStepCount:viewModel.percentageDayStepCount, onStepClick: self.onStepClick, onDistanceClick: self.onDistanceClick,onCaloriesClick: self.onCaloriesClick)
//                       BarChartView(data : viewModel.stepCountData, dataType: .steps)
//
//                    }else {
//                        ProgressView("loading")
//                    }
//                }.alert( viewModel.errorMessage, isPresented: $viewModel.isShowingAlert) {
//
//                }
//
//            }
//
//            .onAppear(perform: {
//
//                viewModel.getHeartRate()
//                viewModel.getHealthData()
//
//
//            }).navigationDestination(isPresented: $isStepClick) {
//                ReportView(viewModel: ReportViewModel(dataType: .steps, title: "stepsReport")).navigationBarBackButtonHidden(false)
//            }
//            .navigationDestination(isPresented: $isDistanceClick) {
//                ReportView(viewModel: ReportViewModel(dataType: .distance, title: "distanceReport")).navigationBarBackButtonHidden(false)
//            }
//            .navigationDestination(isPresented: $isCaloriesClick) {
//                ReportView(viewModel: ReportViewModel(dataType: .energy, title: "caloriesReport")).navigationBarBackButtonHidden(false)
//            }
//
////            VStack{
////                WebUIView(viewModel: WebViewModel(url: "https://medclaim.hpcl.co.in/medclaim/pme_new.jsp?c=675g19kGyol8eZQ/vqH2SQ=="))
////                    .frame(width: 400, height: 400)
////            }
//
//        }
//        .toolbar{
//            CustomToolBar(title : "HP Fitness", transparency: false)
//        }
//
//        TabView {
//            // Text("First Tab")
//
//           // HomeView()
//           // (HomeMenuSubView())
//            HomeTab()
//                .tabItem {
//
//                    Image(systemName: "house")
//
//                    Text("Home")
//                }
//
//          //  Text("Second Tab")
//            SetPreferencesView()
//                .tabItem {
//                    Image(systemName: "2.circle")
//                    Text("Second")
//                }
//            //Text("Third Tab")
//
//
//                WebUIView(viewModel: WebViewModel(url: "http://medclaim.hpcl.co.in/medclaim/pme.jsp?c=675g19kGyol8eZQ/vqH2SQ==")).frame(width: 400, height: 600)
//                    .toolbar{
//                    CustomToolBar(title : "PME", transparency: false)
//
//            }
//
////                .tabItem {
////                    Image(systemName: "2.circle")
////                    Text("Third")
////                }
////
//            SetPreferencesView()
////                .tabItem {
////                    Image(systemName: "2.circle")
////                    Text("Second")
////                }
//
//
//
//
//        }
//
//
//
//    }
//
//
//    func onStepClick() {
//
//        isStepClick = true;
//
//    }
//
//    func onDistanceClick() {
//
//        isDistanceClick = true;
//
//    }
//
//    func onCaloriesClick() {
//
//        isCaloriesClick = true;
//
//    }
//
//
//}

//struct HomeView: View {
//    
//    
//    @ObservedObject var viewModel = HomeViewModel()
//    @State  var isStepClick = false
//    @State  var isDistanceClick = false
//    @State  var isCaloriesClick = false
//
//    var body: some View {
//        
//        Form(){
//            
//            NavigationStack{
//                VStack{
//                    if(viewModel.isLoading == false){
//                        
//                       
//                        GraphicalView(energyBurnedToday: viewModel.energyBurnedToday, heartRate:viewModel.heartRate, walkingDistance: viewModel.walkingDistance, dayStepCount: viewModel.dayStepCount, percentageDayStepCount:viewModel.percentageDayStepCount, onStepClick: self.onStepClick, onDistanceClick: self.onDistanceClick,onCaloriesClick: self.onCaloriesClick )
//                        BarChartView(data : viewModel.stepCountData, dataType: .steps)
//                        
//                        
//                    }else {
//                        ProgressView("loading")
//                    }
//                }.alert( viewModel.errorMessage, isPresented: $viewModel.isShowingAlert) {
//                    
//                }
//            }
//            
//            .onAppear(perform: {
//               
//                viewModel.getHeartRate()
//                viewModel.getHealthData()
//                
//            }).navigationDestination(isPresented: $isStepClick) {
//                ReportView(viewModel: ReportViewModel(dataType: .steps, title: "stepsReport")).navigationBarBackButtonHidden(false)
//            }
//            .navigationDestination(isPresented: $isDistanceClick) {
//                ReportView(viewModel: ReportViewModel(dataType: .distance, title: "distanceReport")).navigationBarBackButtonHidden(false)
//            }
//            .navigationDestination(isPresented: $isCaloriesClick) {
//                ReportView(viewModel: ReportViewModel(dataType: .energy, title: "caloriesReport")).navigationBarBackButtonHidden(false)
//            }
//          
//        }
//
//    }
//    
//    func onStepClick() {
//       
//        isStepClick = true;
//           
//    }
//    
//    func onDistanceClick() {
//        isDistanceClick = true;
//    }
//    
//    func onCaloriesClick() {
//        isCaloriesClick = true;
//           
//    }
//    
//    
//}
import SwiftUI

struct HomeView: View {

    @ObservedObject var viewModel = HomeViewModel()
    @State var isStepClick = false
    @State var isDistanceClick = false
    @State var isCaloriesClick = false
    @State  var isWebViewPresented = false


    var body: some View {

        Form() {

            NavigationStack {
                VStack {
                    if !viewModel.isLoading {
                        GraphicalView(energyBurnedToday: viewModel.energyBurnedToday, heartRate: viewModel.heartRate, walkingDistance: viewModel.walkingDistance, dayStepCount: viewModel.dayStepCount, percentageDayStepCount: viewModel.percentageDayStepCount, onStepClick: self.onStepClick, onDistanceClick: self.onDistanceClick, onCaloriesClick: self.onCaloriesClick)
                        BarChartView(data: viewModel.stepCountData, dataType: .steps)
                       
                       //  Label below the BarChartView
//                        NavigationLink(
//                            destination:  WebUIView(viewModel: WebViewModel(url: "http://lubesws.hpcl.co.in/MobileOcrWebService/HealthApp/leaderBoardTop10enc_new.jsp?emailid=" + (UserDefaults.standard.email ?? ""))), // Specify the destination view
//                            isActive: $isWebViewPresented, // Binding to control navigation
//                            label: {
//                                Text("Click here to view Leaderboard")
//                                    .foregroundColor(.white)
//                                    .background(Color.blue)
//                                   // .padding(.top)
//                                // Adjust the top padding of the button
//
//                                    .padding(EdgeInsets(top: 20, leading: 0, bottom: 20, trailing: -50))
//                                    .multilineTextAlignment(.center)
//                                                   .padding()
//                                Spacer()
//                                  }
//                                // Create space at the bottom
//                        )
//                       Spacer()
//                         .toolbar {
//                                     CustomToolBar(title: "HP Fitness", transparency: false)
//                                 }
                        
                      //  BarChartView(data: viewModel.stepCountData, dataType: .steps)
                      
                    } else {
                        ProgressView("loading")
                    }
                }.alert(viewModel.errorMessage, isPresented: $viewModel.isShowingAlert) {

                }
            }
            .onAppear(perform: {
                viewModel.getHeartRate()
                //viewModel.getHealthData()
//                viewModel.getLastUpdatedDateApiCall(request: LastUpdatedDateRequest(emailid: UserDefaults.standard.email, token: UserDefaults.standard.token))
                viewModel.getDataForNoOfDays(checkDate: true, noOfDays: 7)
            })
            .navigationDestination(isPresented: $isStepClick) {
                ReportView(viewModel: ReportViewModel(dataType: .steps, title: "stepsReport", isManualData: false)).navigationBarBackButtonHidden(false)
            }
            .navigationDestination(isPresented: $isDistanceClick) {
                ReportView(viewModel: ReportViewModel(dataType: .distance, title: "distanceReport", isManualData: false)).navigationBarBackButtonHidden(false)
            }
            .navigationDestination(isPresented: $isCaloriesClick) {
                ReportView(viewModel: ReportViewModel(dataType: .energy, title: "caloriesReport", isManualData: false)).navigationBarBackButtonHidden(false)
            }

            
        }
    }

    func onStepClick() {
        isStepClick = true
    }

    func onDistanceClick() {
        isDistanceClick = true
    }

    func onCaloriesClick() {
        isCaloriesClick = true
    }
    func onLeaderboardClick() {
        isWebViewPresented = true
    }
}


struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}

