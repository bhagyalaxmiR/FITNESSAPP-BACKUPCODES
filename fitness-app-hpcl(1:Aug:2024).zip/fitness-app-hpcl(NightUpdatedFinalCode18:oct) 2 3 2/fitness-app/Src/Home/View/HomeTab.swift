//
//  HomeTab.swift
//  fitness-app
//
//  Created by pundarik rajkhowa on 01/03/23.
//

import SwiftUI

struct HomeTab: View {
    
    @ObservedObject var viewModel = HomeViewModel()
    @State  var isStepClick = false
    @State  var isDistanceClick = false
    @State  var isCaloriesClick = false
    @State  var isWebViewPresented = false

    
    
    var body: some View {
      
        Form(){
            NavigationStack{
                VStack{
                    if(viewModel.isLoading == false){
                        GraphicalView(energyBurnedToday: viewModel.energyBurnedToday, heartRate:viewModel.heartRate, walkingDistance: viewModel.walkingDistance, dayStepCount: viewModel.dayStepCount, percentageDayStepCount:viewModel.percentageDayStepCount, onStepClick: self.onStepClick, onDistanceClick: self.onDistanceClick,onCaloriesClick: self.onCaloriesClick)
                        BarChartView(data : viewModel.stepCountData, dataType: .steps)
                        
                    }else {
                        ProgressView("loading")
                    }
                }.alert( viewModel.errorMessage, isPresented: $viewModel.isShowingAlert) {
                    
                }
               //  Label below the BarChartView
//                Button("Click here to view Leaderboard") {
//                    isWebViewPresented = true
//                }
                
//               //  WebView navigation
//                .navigationDestination(isPresented: $isWebViewPresented) {
//                    WebUIView(viewModel: WebViewModel(url: "http://lubesws.hpcl.co.in/MobileOcrWebService/HealthApp/leaderBoardTop10enc_new.jsp?emailid=" + (UserDefaults.standard.email ?? "")))
//                }
                
            }
//            .toolbar {
//                CustomToolBar(title: "HP", transparency: false)
//            }
//            
//            .sheet(isPresented: $isWebViewPresented, onDismiss: {
//                // Handle WebView dismissal if needed
//            }) {
//                WebUIView(viewModel: WebViewModel(url: "http://lubesws.hpcl.co.in/MobileOcrWebService/HealthApp/leaderBoardTop10enc_new.jsp?emailid=" + (UserDefaults.standard.email ?? "")))
//            }
        
            .onAppear(perform: {
               
                viewModel.getHeartRate()
                //viewModel.getHealthData()
                viewModel.getLastUpdatedDateApiCall(request: LastUpdatedDateRequest(emailid: UserDefaults.standard.email, token: UserDefaults.standard.token))
                
                
            }).navigationDestination(isPresented: $isStepClick) {
                ReportView(viewModel: ReportViewModel(dataType: .steps, title: "stepsReport", isManualData: false)).navigationBarBackButtonHidden(false)
            }
            .navigationDestination(isPresented: $isDistanceClick) {
                ReportView(viewModel: ReportViewModel(dataType: .distance, title: "distanceReport", isManualData: false)).navigationBarBackButtonHidden(false)
            }
            .navigationDestination(isPresented: $isCaloriesClick) {
                ReportView(viewModel: ReportViewModel(dataType: .energy, title: "caloriesReport", isManualData: false)).navigationBarBackButtonHidden(false)
            }
           
            
            //Here agian commented the below pme file on 13/june/2023 as per sir said//
          
//            VStack{
//                WebUIView(viewModel: WebViewModel(url: "https://medclaim.hpcl.co.in/medclaim/pme_new.jsp?c=675g19kGyol8eZQ/vqH2SQ=="))
//                    .frame(width: 400, height: 400)
//            }
            
        }
        .toolbar{
            CustomToolBar(title : "HP Fitness", transparency: false)
        }
        
      
       
      
    }
    
    func onStepClick() {
        isStepClick = true;
    }
    
    
    func onDistanceClick() {
        isDistanceClick = true;
    }
    
    func onCaloriesClick() {
       
        isCaloriesClick = true;
           
    }
    func onClickLeaderboard()
    {
        isWebViewPresented = true;
    }
    
    
}

struct HomeTab_Previews: PreviewProvider {
    static var previews: some View {
        HomeTab()
    }
}
