//
//  HomeViewModel.swift
//  fitness-app
//
//  Created by Babu Lal on 14/12/22.
//

import Foundation
import HomeKit
import SwiftUI
import HealthKit
import Alamofire



class HomeViewModel: ObservableObject {
    
    @Published var isLoading = false;
    @Published var isSuccess = false;
    
    
    @Published var stepList: [StepData] = [];
    
    @Published var heartRate = 0;
    
    @Published var energyBurnedToday = 0.0;
    @Published var walkingDistance = 0.0;
    @Published var dayStepCount = 0.0;
    @Published var percentageDayStepCount = 0.0;
    
    @Published var stepCountData: [[Date: Double]] = []
    @Published var distanceData: [[Date: Double]] = []
    @Published var energyData: [[Date: Double]] = []
    
    @Published var stepCountDataUp: [[Date: Double]] = []
    @Published var distanceDataUp: [[Date: Double]] = []
    @Published var energyDataUp: [[Date: Double]] = []
    
    
    @Published var finalDataUpload: [FitnessDataPushRequest] = []
    let operationQueue = OperationQueue()
    
    
    @Published  var errorMessage = ""
    @Published  var isShowingAlert = false
    @Published var result: Any?
    
    @Published  var lastUpdatedDateResponse : LastUpdatedDateResponse?
    private let healthStore = HKHealthStore()
    static var operationResults: [String: Any] = [:]
   // let dispatchGroup = DispatchGroup()
    
    func fetchSensorData(completion: @escaping ([HKQuantitySample]?, Error?) -> Void) {
        let quantityType = HKObjectType.quantityType(forIdentifier: .heartRate)! // Replace with your desired data type
        
        // Get the bundle identifier of the Health app
        let healthAppBundleIdentifier = "com.apple.Health" // Replace with the correct bundle identifier
        
        // Create a predicate to filter out data from the Health app
        let notFromHealthAppPredicate = NSPredicate(format: "sourceRevision.source.bundleIdentifier != %@", healthAppBundleIdentifier)
        
        // Combine the predicates for filtering
        let compoundPredicate = NSCompoundPredicate(andPredicateWithSubpredicates: [notFromHealthAppPredicate])
        
        // Create a query to fetch data
        let query = HKSampleQuery(sampleType: quantityType,
                                  predicate: compoundPredicate,
                                  limit: HKObjectQueryNoLimit,
                                  sortDescriptors: nil) { (query, results, error) in
            if let quantitySamples = results as? [HKQuantitySample] {
                completion(quantitySamples, nil)
            } else if let error = error {
                completion(nil, error)
            }
        }
        healthStore.execute(query)
    }
    
    func getHeartRate(){
        
        print("isPreferences \(UserDefaults.standard.isPreferences)")
        
        GetHeartRate().fetchLatestHeartRateSample( completion: { (success, heartRate, error) in
            
            if(success == true){
                //print("heartRate \(heartRate)")
                DispatchQueue.main.async {
                    self.heartRate = heartRate ?? 0
                }
            }else {
                //print("error \(String(describing: error))")
                
                DispatchQueue.main.async {
                    //self.isLoading = false;
                    self.isShowingAlert = true;
                    self.errorMessage = String(describing: error);
                    
                }
            }
            
        })
    }
    
    
    /*
     Get Last updated Date
     */

    func getLastUpdatedDateApiCall(request: LastUpdatedDateRequest) {
        print("Status_1 : getLastUpdatedDateApiCall")

        DispatchQueue.main.async {
            self.isLoading = true;
        }
        APIServices.shared.callLastUpdatedDate(parameters: request.dictionary ?? [:]) { response in
            if let response = response {
                print("SUCESS_LastDate \(response)")
                DispatchQueue.main.async {
                    self.lastUpdatedDateResponse = response;
                    self.isLoading = false;
                    self.isSuccess = true;
                    
                    let lastUpdatedDate = response.Last_Date;
                    if(lastUpdatedDate != nil){
                        print("Status_2 : getLastUpdatedDateApiCall")


                        self.getDataAccordingToDate();
                    }else {
                        print("Status_3 : getLastUpdatedDateApiCall")

                        //self.getLastOneWeekData()
                        self.dataPreparingForUpload();
                    }
                    
                    //self.dataPreparingForUpload();
                    //self.uploadDataCheck();
                }
            }
        }
    failure: { error in
        print("Status_4 : getLastUpdatedDateApiCall")

        print("error LastDate \(error)")
        
        DispatchQueue.main.async {
            self.errorMessage = "\(error)";
            self.isShowingAlert = true;
            self.isLoading = false;
        }
    }
    }
    
 
    
    
    func getDataForNoOfDays(checkDate: Bool, noOfDays : Int) {
        let group  = DispatchGroup()
        print("Status_0 : getLastOneWeekData \(Date())")
        print("Status_00 : getLastOneWeekData \(noOfDays)")
        DispatchQueue.main.async {
            
            self.isLoading = true;
          
        }
        group.enter()
        group.enter()
        //GetHealthData().fetchDataFor(numberOfDays: noOfDays, dataType: .distance) { [weak self] (response, error) in
            
            GetHealthData().fetchDataForNoOfDays(numberOfDays: noOfDays,dataType: .distance) { [weak self] (response, error) in
                
            guard (error == nil) else {
                
                        group.leave()
                DispatchQueue.main.async {
                    
                    self?.isLoading = false;
                    self?.isShowingAlert = true;
                    self?.errorMessage = String(describing: error);
                }
                return
            }
            
            //group.enter()
            if let healthKitData = response {
                
                
                group.leave()
               
                DispatchQueue.main.async {
                    self?.isLoading = false;
                    //self?.walkingDistanceData = healthKitData;
                    //print("walkingDistanceData\(healthKitData)")
                    if(checkDate == true){
                        self?.distanceData = healthKitData;
                    }
                 
                    self?.distanceDataUp = healthKitData;
                    //self?.walkingDistance = healthKitData[healthKitData.count - 1].values.first!;
                    //var sum = 0
                    //                    self?.walkingDistance = 0.0;
                    //                    for value in healthKitData {
                    //                        // sum += value
                    //
                    //                        let values = Double(value.values.first!);
                    //                        self?.walkingDistance = values;
                    //
                    //                        //print("walkingDistance\(self?.walkingDistance)")
                    //                    }
                    
                    print("Status_2 : getLastOneWeekData")
                  
                    
                }
                
                
            }
        }
        
        
        group.enter()
        group.enter()
        GetHealthData().fetchDataForNoOfDays(numberOfDays: noOfDays,dataType: .steps) { [weak self] (response, error) in

       // GetHealthData().fetchDataFor(numberOfDays: noOfDays, dataType: .steps) { [weak self] (response, error) in
            
            guard (error == nil) else {
                group.leave()
                DispatchQueue.main.async {
                    
                    self!.isLoading = false;
                    self?.isShowingAlert = true;
                    self?.errorMessage = String(describing: error);
                }
                
                return
            }
            if let healthKitData = response {
                group.leave()
                DispatchQueue.main.async {
                    
                    self?.isLoading = false;
                
                    if(checkDate == true){
                        self?.stepCountData = healthKitData;
                    }
                    self?.stepCountDataUp = healthKitData;
                    
                    // print("stepCountData\(self?.stepCountData)")
                    
                    if(healthKitData.count>0){
                        self?.dayStepCount = Double((healthKitData[healthKitData.count-1]).values.first!);
                        
                        if(self?.dayStepCount != nil){
                            if(Double(UserDefaults.standard.stepsADay!)! > (self?.dayStepCount)! ){
                                
                                self?.stepGoalCalculate()
                                
                            }else {
                                UserDefaults.standard.stepsADay = String(self!.dayStepCount);
                                
                                self?.stepGoalCalculate()
                            }
                        }
                      print("Status_3 : getLastOneWeekData")
                    }
                    
                    
                    //                    for value in healthKitData {
                    //                        // sum += value
                    //
                    //                        let values = Double(value.values.first!);
                    //                        self?.totalStepCount += values;
                    //
                    //                        //print("walkingDistance\(self?.walkingDistance)")
                    //                    }
                    
                 

                }
            }
        }
        
        group.enter()
        group.enter()
        //GetHealthData().fetchDataFor(numberOfDays: noOfDays, dataType: .energy) { [weak self] (response, error) in
            GetHealthData().fetchDataForNoOfDays(numberOfDays: noOfDays,dataType: .energy) { [weak self] (response, error) in

            guard (error == nil) else {
               // group.leave()
                DispatchQueue.main.async {
                    
                    self!.isLoading = false;
                    self?.isShowingAlert = true;
                    self?.errorMessage = String(describing: error);
                }
                
                return
            }
            if let healthKitData = response {
                group.leave()
                DispatchQueue.main.async {
                    
                    self?.isLoading = false;
                  
                    if(checkDate == true){
                        self?.energyData = healthKitData;
                    }
                    self?.energyDataUp = healthKitData;
                    
                    // print("stepCountData\(self?.stepCountData)")
                    
                 
                    print("Status_4 : getLastOneWeekData \(String(describing: self?.energyDataUp))")
                    }
                    
                    
                    //                    for value in healthKitData {
                    //                        // sum += value
                    //
                    //                        let values = Double(value.values.first!);
                    //                        self?.totalStepCount += values;
                    //
                    //                        //print("walkingDistance\(self?.walkingDistance)")
                    //                    }
                    
                }
            }
        
        
        
        
     /*   group.enter()
        group.enter()
        GetHealthData().fetchDataFor(numberOfDays: 7, dataType: .energy) { [weak self] (response, error) in
            
            guard (error == nil) else {
                //print("CaloriesDataError \(error)")
                group.leave()
                DispatchQueue.main.async {
                    
                    self!.isLoading = false;
                    self?.isShowingAlert = true;
                    self?.errorMessage = String(describing: error);
                }
                
                return
            }
            if let healthKitData = response {
                group.leave()
                //print("CaloriesData \(healthKitData)")
                
                DispatchQueue.main.async {
                    
                    self?.isLoading = false;
                    //self?.stepCountData = healthKitData;
                    self?.energyData = healthKitData
                    
                    self?.energyBurnedToday = healthKitData[healthKitData.count - 1].values.first!;
                    print("Status_4 : getLastOneWeekData")
                }
            }
            
        

        }  */
        
        group.notify(queue: .main) {
            print("Status_Final : getLastOneWeekData \(Date())")
            
            if(checkDate == true){
                print("Status_Final_1 : getLastOneWeekData \(Date())")

                self.getLastUpdatedDateApiCall(request: LastUpdatedDateRequest(emailid: UserDefaults.standard.email, token: UserDefaults.standard.token))
            }else {
                print("Status_Final_2 : getLastOneWeekData \(Date())")
                self.dataPreparingForUpload();
            }
        }
    }
   
    
    func stepGoalCalculate(){
        
        let total = Double(UserDefaults.standard.stepsADay!)!
        let achieve = self.dayStepCount;
        
        self.percentageDayStepCount = (achieve / total) * 100;
        
        //print("GoalPercentage \(percentageDayStepCount)");
    }
    
   
    
    
    
    func getDataAccordingToDate(){
        print("Status_1 : getDataAccordingToDate")

        let lastUpdatedDate = self.lastUpdatedDateResponse?.Last_Date;
    
        
        //var lastUpdatedDate = "2022-12-19"
        
        //let lastUpdatedDateDate : Date? = lastUpdatedDate!.toDate(dateFormat: DateFormat.local)
        
      //  let yesterdayDate = Date().dayBefore.toString(dateFormat: DateFormat.local)
        
        //print("yesterdayDate \(yesterdayDate)")
        
        //let lastUpdatedDateDate =  ( lastUpdatedDate! + " 18:30:00 +0000")
        let lastUpdatedDateDate =  ( lastUpdatedDate! + " 18:30:00 +0000")
        
        //print("startDateValue_Update_1 \(lastUpdatedDateDate)")
        
        let startDateValue = lastUpdatedDateDate.toDate(dateFormat: DateFormat.localDateTime)
        
        let calendar = Calendar.current
        let today = Date()
        var yesturdayDate = Calendar.current.date(byAdding: .day, value: -1, to: Date())!
        //let dayBeforeYesterdayDate = calendar.date(byAdding: .day, value: -1, to: yesturdayDate)
       // print("YESTURDAYDATE",yesturdayDate)
        //print("YESTURDAYDATE",dayBeforeYesterdayDate)
        
        
        guard let days = calendar.dateComponents([.day],
                                                     from: calendar.startOfDay(for: startDateValue!),
                                                 to:calendar.startOfDay(for: today)).day else {
            
              return
            }
        print("TODAY \(today)")
        print("Status_2_DaysDiff : getDataAccordingToDate \(days)")

        //print("startDateValue_Update \(startDateValue)")
        // print("endDate_Update \(Date())")
        
        getDataForNoOfDays(checkDate: false, noOfDays: days)
        
       // if(yesterdayDate != (lastUpdatedDate!)){
       
        /*    let group  = DispatchGroup()
            
            DispatchQueue.main.async {
                self.isLoading = true;
            }
            
            group.enter()
            group.enter()
          //  GetHealthData().fetchDataFor(numberOfDays: days, dataType: .distance) { [weak self] (response, error) in
            GetHealthData().fetchDataForCustomDateNew(numberOfDays: days,dataType: .distance, startDateValue: startDateValue, endDateValue: Date()) { [weak self] (response, error) in
                
                guard (error == nil) else {
                    group.leave()
                    DispatchQueue.main.async {
                        
                        self?.isLoading = false;
                        self?.isShowingAlert = true;
                        self?.errorMessage = String(describing: error);
                    }
                    return
                }
                if let healthKitData = response {
                    print("Status_2 : getDataAccordingToDate \(healthKitData)")
                    group.leave()
                    DispatchQueue.main.async {
                        
                        self?.isLoading = false;
                        //self?.walkingDistanceData = healthKitData;
                        //print("walkingDistanceData\(healthKitData)")
                        self?.distanceDataUp = healthKitData;
                        //print("distanceDataUp\(self?.distanceDataUp)")
                    }
                }

            }
            
            group.enter()
            group.enter()
            //GetHealthData().fetchDataFor(numberOfDays: days, dataType: .steps) { [weak self] (response, error) in

            GetHealthData().fetchDataForCustomDateNew(numberOfDays: days,dataType: .steps, startDateValue: startDateValue, endDateValue: Date()) { [weak self] (response, error) in
                
                guard (error == nil) else {
                    group.leave()
                    DispatchQueue.main.async {
                        
                        self!.isLoading = false;
                        self?.isShowingAlert = true;
                        self?.errorMessage = String(describing: error);
                    }
                    return
                }
                if let healthKitData = response {
                    print("Status_3 : getDataAccordingToDate : \(healthKitData)")
                    group.leave()
                    DispatchQueue.main.async {
                        self?.isLoading = false;
                        self?.stepCountDataUp = healthKitData;
                        // print("stepCountData\(self?.stepCountData)")
                        //print("stepCountDataUp\(self?.stepCountDataUp)")
                    }
                }
               

            }
            group.enter()
            group.enter()
            //GetHealthData().fetchDataFor(numberOfDays: days, dataType: .energy) { [weak self] (response, error) in

            GetHealthData().fetchDataForCustomDateNew(numberOfDays: days,dataType: .energy, startDateValue: startDateValue, endDateValue: Date()) { [weak self] (response, error) in
                
                guard (error == nil) else {
                    //print("CaloriesDataError \(error)")
                    group.leave()
                    DispatchQueue.main.async {
                        
                        self!.isLoading = false;
                        self?.isShowingAlert = true;
                        self?.errorMessage = String(describing: error);
                    }
                    return
                }
                if let healthKitData = response {
                    //print("CaloriesData \(healthKitData)")
                    print("Status_4 : getDataAccordingToDate \(healthKitData)")
                    group.leave()
                    DispatchQueue.main.async {
                        self?.isLoading = false;
                        //self?.stepCountData = healthKitData;
                        self?.energyDataUp = healthKitData
                        //print("energyDataUp\(String(describing: self?.energyDataUp))")
                      //  self?.dataPreparingForUpload();
                    }
                }

            }
           
            
         
            group.notify(queue: .main) {
                print("Status_5 : getDataAccordingToDate")

                self.dataPreparingForUpload();
                
            }    */
        
       // }
    }
    
    func dataPreparingForUpload(){
        print("Status_1 : dataPreparingForUpload \(Date())")

        
   /*     let lastUpdatedDate = self.lastUpdatedDateResponse?.Last_Date;
        
        guard lastUpdatedDate != nil else {
            return
        }
        
        //var lastUpdatedDate = "2022-12-19"
        
        //let lastUpdatedDateDate : Date? = lastUpdatedDate!.toDate(dateFormat: DateFormat.local)
        
        let yesterdayDate = Date().dayBefore.toString(dateFormat: DateFormat.local)
        
        //print("yesterdayDate \(yesterdayDate)")
        //print("lastUpdatedDate \(lastUpdatedDate)")
        
        if(yesterdayDate != (lastUpdatedDate!)){
            
            //print("Data Updating...")
            //print("stepCountDataUp_1 \(stepCountDataUp)")
        }else {
            //print("Data already updated yesterday")
        } */
        
        let group  = DispatchGroup()

        group.enter()
     
        
        DispatchQueue.main.async {
            print("DispatchGroup Running")
            print("Status_2 : dataPreparingForUpload:stepCountDataUp \(self.stepCountDataUp)")
            print("Status_2 : dataPreparingForUpload:distanceDataUp \(self.distanceDataUp)")
            print("Status_2 : dataPreparingForUpload : \(self.energyDataUp)")

            for (value) in self.stepCountDataUp {
                let dateDate = value.keys.first;
                let dateStr = dateDate!.toString(dateFormat: DateFormat.local);
                
                //print("dateDate \(dateDate)")
                //print("dateStr \(dateStr)")
                
    //            if(dateStr > lastUpdatedDate!){
    //
    //            }
                self.finalDataUpload.append(FitnessDataPushRequest(api_date : dateStr,datatype : Constants.dataTypeStepCount, gmailid: UserDefaults.standard.email, token: UserDefaults.standard.token, step_count:  String(describing: value.values.first!)))
                print("Status_3 : dataPreparingForUpload \(Date())")
            }
            
            
            for (value) in self.distanceDataUp {
                let dateDate = value.keys.first;
                let dateStr = dateDate!.toString(dateFormat: DateFormat.local);
                
    //            if(dateStr > lastUpdatedDate!){
    //
    //
    //            }
                self.finalDataUpload.append(FitnessDataPushRequest(api_date : dateStr,datatype : Constants.dataTypeDistance, gmailid: UserDefaults.standard.email, token: UserDefaults.standard.token, distance:  String(describing: (value.values.first!) )))
       
                print("Status_4 : dataPreparingForUpload \(Date())")

            }
            
            
            for (value) in self.energyDataUp {
                let dateDate = value.keys.first;
                let dateStr = dateDate!.toString(dateFormat: DateFormat.local);
                
    //            if(dateStr > lastUpdatedDate!){
    //                    }
                
                self.finalDataUpload.append(FitnessDataPushRequest(api_date : dateStr,datatype : Constants.dataTypeEnergy, gmailid: UserDefaults.standard.email, token: UserDefaults.standard.token, calories:  String(describing: value.values.first!)))

                print("Status_5 : dataPreparingForUpload \(Date())")

            }
            
            group.leave()
        }
        
        
        
      
        
      
      
    
        
        
           group.notify(queue: .main) {
               print("Status_Final : dataPreparingForUpload \(self.finalDataUpload)")


               // Perform task 2
               self.finalDataPushApiCall(request:self.finalDataUpload)
               
           }
         
     
        
    
    }
    
    /*
     Push Fitness Steps Data
     */
    
    func finalDataPushApiCall(request: [FitnessDataPushRequest]) {
        DispatchQueue.main.async {
            self.isLoading = true;
        }
        print("Status_1 : finalDataPushApiCall")


        APIServices.shared.finessDataPush(parameters: request) { response in
            if let response = response {
                print("success Push \(response)")
                print("Status_2 : finalDataPushApiCall")

                DispatchQueue.main.async {
                    self.isLoading = false;
                    self.isSuccess = true;
                    
                }
            }
        }
    failure: { error in
        print("error Push \(error)")
        print("Status_3 : finalDataPushApiCall")

        DispatchQueue.main.async {
            self.errorMessage = "\(error)";
            self.isShowingAlert = false;
            self.isLoading = false;
        }
        
    }
    }
    
    
    //    // Define a function to fetch step count data from HealthKit
    //    func getStepsFromHealthKit(completion: @escaping (Double?, Error?) -> Void) {
    //        // Check if HealthKit is available on the device
    //        guard HKHealthStore.isHealthDataAvailable() else {
    //            completion(nil, NSError(domain: "YourAppDomain", code: 1, userInfo: [NSLocalizedDescriptionKey: "HealthKit is not available on this device."]))
    //            return
    //        }
    //
    //        // Define the HealthKit data type for step count
    //        let stepCountType = HKQuantityType.quantityType(forIdentifier: .stepCount)!
    //
    //        // Create a HealthKit store instance
    //        let healthStore = HKHealthStore()
    //
    //        // Request authorization from the user to access step count data
    //        healthStore.requestAuthorization(toShare: nil, read: [stepCountType]) { (success, error) in
    //            if success {
    //                // Authorization granted, fetch step count data
    //                let calendar = Calendar.current
    //                let now = Date()
    //                let startOfDay = calendar.startOfDay(for: now)
    //                let predicate = HKQuery.predicateForSamples(withStart: startOfDay, end: now, options: .strictStartDate)
    //
    //                let query = HKStatisticsQuery(quantityType: stepCountType,
    //                                              quantitySamplePredicate: predicate,
    //                                              options: .cumulativeSum) { (query, result, error) in
    //                    if let result = result, let sum = result.sumQuantity() {
    //                        let steps = sum.doubleValue(for: HKUnit.count())
    //                        completion(steps, nil)
    //                    } else {
    //                        completion(nil, error)
    //                    }
    //                }
    //
    //                healthStore.execute(query)
    //            } else {
    //                // Authorization denied or an error occurred
    //                completion(nil, error)
    //            }
    //        }
    //    }
    
    // Define a function to fetch distance data from HealthKit
    func getDistanceFromHealthKit(completion: @escaping (Double?, Error?) -> Void) {
        // Check if HealthKit is available on the device
        guard HKHealthStore.isHealthDataAvailable() else {
            completion(nil, NSError(domain: "YourAppDomain", code: 1, userInfo: [NSLocalizedDescriptionKey: "HealthKit is not available on this device."]))
            return
        }
        
        // Define the HealthKit data type for distance
        let distanceType = HKQuantityType.quantityType(forIdentifier: .distanceWalkingRunning)!
        
        // Create a HealthKit store instance
        let healthStore = HKHealthStore()
        
        // Request authorization from the user to access distance data
        healthStore.requestAuthorization(toShare: nil, read: [distanceType]) { (success, error) in
            if success {
                // Authorization granted, fetch distance data
                let calendar = Calendar.current
                let now = Date()
                let startOfDay = calendar.startOfDay(for: now)
                let predicate = HKQuery.predicateForSamples(withStart: startOfDay, end: now, options: .strictStartDate)
                
                let query = HKStatisticsQuery(quantityType: distanceType,
                                              quantitySamplePredicate: predicate,
                                              options: .cumulativeSum) { (query, result, error) in
                    if let result = result, let sum = result.sumQuantity() {
                        let distance = sum.doubleValue(for: HKUnit.meter())
                        completion(distance, nil)
                    } else {
                        completion(nil, error)
                    }
                }
                
                healthStore.execute(query)
            } else {
                // Authorization denied or an error occurred
                completion(nil, error)
            }
        }
    }
    
    
  /*  var stepsBlock : BlockOperation {
        let block = BlockOperation {
            
            // Here code for getting steps from Health app
            //    let stepgoal = stepDataPushApiCall(request: [FitnessDataPushRequest])
            getStepsFromHealthKit { (steps, error) in
                if let error = error {
                    print("Error fetching step count: \(error.localizedDescription)")
                } else if let steps = steps {
                    print("Step count: \(steps)")
                    //operationResults["steps"] = steps
                } else {
                    print("Step count not available.")
                }
 }
            
        // Define a function to fetch step count data from HealthKit
        func getStepsFromHealthKit(completion: @escaping (Double?, Error?) -> Void) {
            // Check if HealthKit is available on the device
            guard HKHealthStore.isHealthDataAvailable() else {
                completion(nil, NSError(domain: "YourAppDomain", code: 1, userInfo: [NSLocalizedDescriptionKey: "HealthKit is not available on this device."]))
                return
            }
            
            // Define the HealthKit data type for step count
            let stepCountType = HKQuantityType.quantityType(forIdentifier: .stepCount)!
            
            // Create a HealthKit store instance
            let healthStore = HKHealthStore()
            
            // Request authorization from the user to access step count data
            healthStore.requestAuthorization(toShare: nil, read: [stepCountType]) { (success, error) in
                if success {
                    // Authorization granted, fetch step count data
                    let calendar = Calendar.current
                    let now = Date()
                    let startOfDay = calendar.startOfDay(for: now)
                    let predicate = HKQuery.predicateForSamples(withStart: startOfDay, end: now, options: .strictStartDate)
                    let query = HKStatisticsQuery(quantityType: stepCountType,
                                                  quantitySamplePredicate: predicate,
                                                  options: .cumulativeSum) { (query, result, error) in
                        if let result = result, let sum = result.sumQuantity() {
                            let steps = sum.doubleValue(for: HKUnit.count())
                            completion(steps, nil)
                        } else {
                            completion(nil, error)
                        }
                    }
                    
                    healthStore.execute(query)
                } else {
                    // Authorization denied or an error occurred
                    completion(nil, error)
                }
            }
        }
        return block
        }()
}
    
        
    let distanceBlock = BlockOperation {
        getDistanceFromHealthKit { (distance, error) in
            if let error = error {
                print("Error fetching distance: \(error.localizedDescription)")
            } else if let distance = distance {
                print("Distance: \(distance)")
                // Now, you can use the 'distance' value in your logic
                // You may also update a property in your SwiftUI view model
                // e.g., self.viewModel.distance = distance
            } else {
                print("Distance data not available.")
            }
        }
        
        // Define a function to fetch distance data from HealthKit
        func getDistanceFromHealthKit(completion: @escaping (Double?, Error?) -> Void) {
            // Check if HealthKit is available on the device
            guard HKHealthStore.isHealthDataAvailable() else {
                completion(nil, NSError(domain: "YourAppDomain", code: 1, userInfo: [NSLocalizedDescriptionKey: "HealthKit is not available on this device."]))
                return
            }
            
            // Define the HealthKit data type for distance
            let distanceType = HKQuantityType.quantityType(forIdentifier: .distanceWalkingRunning)!
            
            // Create a HealthKit store instance
            let healthStore = HKHealthStore()
            
            // Request authorization from the user to access distance data
            healthStore.requestAuthorization(toShare: nil, read: [distanceType]) { (success, error) in
                if success {
                    // Authorization granted, fetch distance data
                    let calendar = Calendar.current
                    let now = Date()
                    let startOfDay = calendar.startOfDay(for: now)
                    let predicate = HKQuery.predicateForSamples(withStart: startOfDay, end: now, options: .strictStartDate)
                    
                    let query = HKStatisticsQuery(quantityType: distanceType,
                                                  quantitySamplePredicate: predicate,
                                                  options: .cumulativeSum) { (query, result, error) in
                        if let result = result, let sum = result.sumQuantity() {
                            let distance = sum.doubleValue(for: HKUnit.meter())
                            completion(distance, nil)
                        } else {
                            completion(nil, error)
                        }
                    }
                    
                    healthStore.execute(query)
                } else {
                    // Authorization denied or an error occurred
                    completion(nil, error)
                }
            }
        }
        
    }
    
    let caloriesBlock = BlockOperation {
        let block = BlockOperation {
            
            
            // Here code for getting calories from Health app
            getCaloriesFromHealthKit { (calories, error) in
                if let error = error {
                    print("Error fetching calories: \(error.localizedDescription)")
                } else if let calories = calories {
                    print("Calories: \(calories)")
                    // Now, you can use the 'calories' value in your logic
                    // You may also update a property in your SwiftUI view model
                    // e.g., self.viewModel.calories = calories
                } else {
                    print("Calories data not available.")
                }
                
            }
            
            
            // Define a function to fetch calories data from HealthKit
            func getCaloriesFromHealthKit(completion: @escaping (Double?, Error?) -> Void) {
                // Check if HealthKit is available on the device
                guard HKHealthStore.isHealthDataAvailable() else {
                    completion(nil, NSError(domain: "YourAppDomain", code: 1, userInfo: [NSLocalizedDescriptionKey: "HealthKit is not available on this device."]))
                    return
                }
                
                // Define the HealthKit data type for calories burned
                let caloriesType = HKQuantityType.quantityType(forIdentifier: .activeEnergyBurned)!
                
                // Create a HealthKit store instance
                let healthStore = HKHealthStore()
                
                // Request authorization from the user to access calories data
                healthStore.requestAuthorization(toShare: nil, read: [caloriesType]) { (success, error) in
                    if success {
                        // Authorization granted, fetch calories data
                        let calendar = Calendar.current
                        let now = Date()
                        let startOfDay = calendar.startOfDay(for: now)
                        let predicate = HKQuery.predicateForSamples(withStart: startOfDay, end: now, options: .strictStartDate)
                        
                        let query = HKStatisticsQuery(quantityType: caloriesType,
                                                      quantitySamplePredicate: predicate,
                                                      options: .cumulativeSum) { (query, result, error) in
                            if let result = result, let sum = result.sumQuantity() {
                                let calories = sum.doubleValue(for: HKUnit.kilocalorie())
                                completion(calories, nil)
                            } else {
                                completion(nil, error)
                            }
                        }
                        
                        healthStore.execute(query)
                    } else {
                        // Authorization denied or an error occurred
                        completion(nil, error)
                    }
                }
                
                // Create an operation queue
                let operationQueue = OperationQueue()
                
                // Add operations to the queue
                operationQueue.addOperations([stepsBlock, distanceBlock, caloriesBlock, apiCallBlock], waitUntilFinished: false)
            }
        }
        
        let apiCallBlock = BlockOperation {
            // Add dependencies to ensure data retrieval blocks execute first
            apiCallBlock.addDependency(stepsBlock)
            apiCallBlock.addDependency(distanceBlock)
            apiCallBlock.addDependency(caloriesBlock)

            // Make the API call using the data fetched in the data retrieval blocks
            // Update view model properties or perform API-related tasks here
            // For example:
            dataPreparingForUpload(steps: stepsBlock.result, calories: caloriesBlock.result, distance: distanceBlock.result) { apiResponse, error in
                if let error = error {
                    // Handle API call error
                    print("API Call Error: \(error.localizedDescription)")
                } else if let response = apiResponse {
                    // Handle the API response
                    print("API Call Success: \(response)")
                }
            }
        }
    } */
    
  
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
