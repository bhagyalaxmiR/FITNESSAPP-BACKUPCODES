//
//  UpdateCheckResponse.swift
//  fitness-app
//
//  Created by Babu Lal on 16/01/23.
//

import Foundation
import Foundation

struct UpdateCheckResponse: Codable {
    
    var resultCount : Int?       = nil
    var results     : [Results]? = []
}

struct Results: Codable {
    
    var isGameCenterEnabled                : Bool?     = nil
    var ipadScreenshotUrls                 : [String]? = []
    var appletvScreenshotUrls              : [String]? = []
    var artworkUrl60                       : String?   = nil
    var artworkUrl512                      : String?   = nil
    var artworkUrl100                      : String?   = nil
    var artistViewUrl                      : String?   = nil
    var screenshotUrls                     : [String]? = []
    var features                           : [String]? = []
    var supportedDevices                   : [String]? = []
    var advisories                         : [String]? = []
    var kind                               : String?   = nil
    var currency                           : String?   = nil
    var currentVersionReleaseDate          : String?   = nil
    var releaseNotes                       : String?   = nil
    var minimumOsVersion                   : String?   = nil
    var trackCensoredName                  : String?   = nil
    var languageCodesISO2A                 : [String]? = []
    var fileSizeBytes                      : String?   = nil
    var sellerUrl                          : String?   = nil
    var formattedPrice                     : String?   = nil
    var contentAdvisoryRating              : String?   = nil
    var averageUserRatingForCurrentVersion : Int?      = nil
    var userRatingCountForCurrentVersion   : Int?      = nil
    var averageUserRating                  : Int?      = nil
    var trackViewUrl                       : String?   = nil
    var trackContentRating                 : String?   = nil
    var artistId                           : Int?      = nil
    var artistName                         : String?   = nil
    var genres                             : [String]? = []
    var price                              : Int?      = nil
    var description                        : String?   = nil
    var genreIds                           : [String]? = []
    var bundleId                           : String?   = nil
    var isVppDeviceBasedLicensingEnabled   : Bool?     = nil
    var releaseDate                        : String?   = nil
    var primaryGenreName                   : String?   = nil
    var primaryGenreId                     : Int?      = nil
    var trackId                            : Int?      = nil
    var trackName                          : String?   = nil
    var sellerName                         : String?   = nil
    var version                            : String?   = nil
    var wrapperType                        : String?   = nil
    var userRatingCount                    : Int?      = nil
    

}
