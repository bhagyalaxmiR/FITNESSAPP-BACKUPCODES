//
//  UpdateCheckViewModel.swift
//  fitness-app
//
//  Created by Babu Lal on 16/01/23.
//

import Foundation
import SwiftUI

class UpdateCheckViewModel: ObservableObject {
    
    @Published var isLoadingAppStoreVersion = false
    @Published  var errorMessageAppStoreVersion = ""
    @Published  var isShowingAlertAppStoreVersion = false
    @Published  var isCheckingVersion = false
        
    @Published var isSuccessAppStoreVersion = false
    
    @Published  var responseData : UpdateCheckResponse?
    
    @Published  var appStoreVersion : String? = ""

    @Published  var appLocalVersion : String? = Constants.appVersion

    func retriveAppStoreVersion() {
        DispatchQueue.main.async {
            self.isLoadingAppStoreVersion = true;
        }
        APIServices.shared.callAppStoreVersionCheck() { response in
            if let response = response {
                
                print("responseAppStore \(response)")
                DispatchQueue.main.async {
                    self.responseData = response;
                    self.isLoadingAppStoreVersion = false;
                    self.isSuccessAppStoreVersion = true;
                    
                }
                
               guard response.resultCount != nil else {
                    return;
                }
                
                guard response.results != nil else {
                     return;
                 }
                
                guard response.results![0].version != nil else {
                     return;
                 }
                
                self.appStoreVersion = response.results![0].version
                print("AppStoreVersion \(String(describing: self.appStoreVersion))")
                print("AppLocalVersion \(String(describing: self.appLocalVersion))")
                                
                    if ((self.appLocalVersion!) < (self.appStoreVersion!)){
                        self.isCheckingVersion = true
                        print("checkversion",self.isCheckingVersion)
                    }
            }
        }
    failure: { error in
        
        print("errorAppStore \(error)")
        
        DispatchQueue.main.async {
            self.errorMessageAppStoreVersion = "\(error)";
            self.isShowingAlertAppStoreVersion = true;
            self.isLoadingAppStoreVersion = false;
        }
    }
    }
}

