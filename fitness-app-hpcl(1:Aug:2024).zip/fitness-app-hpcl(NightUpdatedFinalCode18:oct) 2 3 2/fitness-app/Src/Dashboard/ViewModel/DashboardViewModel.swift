//
//  DashboardViewModel.swift
//  fitness-app
//
//  Created by Babu Lal on 14/12/22.
//

import Foundation
//
//  AuthenticationViewModal.swift
//  fitness-app
//
//  Created by Babu Lal on 13/12/22.
//

import Foundation

class DashboardViewModel: ObservableObject {
    
    @Published  var errorMessage = "";
    @Published var isLoading = false;
    @Published var isSuccess = false;

}
