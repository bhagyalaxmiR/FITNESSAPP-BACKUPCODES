//
//  UIPreferences.swift
//  fitness-app
//
//  Created by Babu Lal on 30/12/22.
//

import Foundation

class UIPreferences {
    
    static func setPreference(token: String?, preference : String?,heart_point : String?, calorie : String?,distance:String?, move_minute:String?, stepGoal :String?,heartGoal : String?){
        
        UserDefaults.standard.token = token;
        

        
        
        if(preference == "Y"){
            UserDefaults.standard.isPreferences = preference == "Y" ? true : false;
           // UserDefaults.standard.isPreferences = true;
            UserDefaults.standard.isHeartPoint = heart_point == "Y" ? true : false;
            UserDefaults.standard.isCalories = calorie == "Y" ? true : false;
            UserDefaults.standard.isDistance = distance == "Y" ? true : false;
            UserDefaults.standard.isMoveMinute = move_minute == "Y" ? true : false;

          
        }else {
            
            
            UserDefaults.standard.isPreferences = false;
           // UserDefaults.standard.isPreferences = true;
            UserDefaults.standard.isHeartPoint = false;
            UserDefaults.standard.isCalories = false;
            UserDefaults.standard.isDistance = false;
            UserDefaults.standard.isMoveMinute = false;
        }
        
      
        
        
        UserDefaults.standard.stepsADay = stepGoal;
        UserDefaults.standard.heartPointADay = heartGoal;
        
    }
    
}
