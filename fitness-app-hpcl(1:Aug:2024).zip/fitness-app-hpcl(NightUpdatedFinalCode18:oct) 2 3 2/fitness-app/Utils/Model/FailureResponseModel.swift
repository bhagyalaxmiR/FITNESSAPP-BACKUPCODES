//
//  FailureResponseModel.swift
//  fitness-app
//
//  Created by Babu Lal on 02/01/23.
//

import Foundation
struct FailureResponseModel: Codable {
    var status: String?;
  
    
}
