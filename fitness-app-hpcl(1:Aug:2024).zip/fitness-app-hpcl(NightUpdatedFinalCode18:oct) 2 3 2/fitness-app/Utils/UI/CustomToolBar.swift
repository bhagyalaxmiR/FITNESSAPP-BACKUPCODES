//
//  CustomToolBar.swift
//  fitness-app
//
//  Created by Babu Lal on 18/12/22.
//

import Foundation
import SwiftUI

struct CustomToolBar: View {
    
    var title = "appName";
    var transparency = false;
    //    var body: some View {
    //            HStack {
    //                Image("logo")
    //                    .resizable()
    //                    .aspectRatio(2, contentMode: .fit)
    //                    .imageScale(.large)
    //                Text(LocalizedStringKey(title)).foregroundColor(Color.theme.primary)
    //
    //            }.foregroundColor(transparency ? Color.clear : Color.theme.toolbarBackground)
    //            //.frame(width: .infinity)
   
    //    }
    var body: some View {
        NavigationStack {
            Text("")
                //.navigationBarTitle(LocalizedStringKey(title),displayMode: .inline)
                
                .navigationBarTitleDisplayMode(.inline)
               
                .toolbar {
                                        
                    ToolbarItem(
                        id: "copy",
                        placement: .principal,
                        showsByDefault: true
                    ) {
                        
                        HStack{
//                            Image("logo")
//                                .resizable()
//                                .aspectRatio(2, contentMode: .fit)
//                                .imageScale(.large)
                            
                            
                            Image("logo")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                //.imageScale(.large)
        
                            Text(LocalizedStringKey(title))
                        }.padding([.top,.bottom], CGFloat.theme.smallSpacing)
                       
                    }
                  
                }
        }
    }
    
}





