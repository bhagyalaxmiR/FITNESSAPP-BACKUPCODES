//
//  CustomCalendarView.swift
//  fitness-app
//
//  Created by Babu Lal on 29/12/22.
//

import SwiftUI

struct CustomCalendarView: View {
    
    private let calendar: Calendar
    private let monthDayFormatter: DateFormatter
    private let dayFormatter: DateFormatter
    private let weekDayFormatter: DateFormatter
    private let timeFormatter: DateFormatter
    
    @State var selectedDate = Self.now
    private static var now = Date() // Cache now
    
    //var dateChange : (_ days:[Date]) -> void
    var myfunc: (([Date]) -> Void)? = nil


    init(calendar: Calendar, myfunc : @escaping (_ days: [Date]) -> Void) {
        
        self.calendar = calendar
        self.monthDayFormatter = DateFormatter(dateFormat: "MM/dd", calendar: calendar)
        self.dayFormatter = DateFormatter(dateFormat: "d", calendar: calendar)
        self.weekDayFormatter = DateFormatter(dateFormat: "EEE", calendar: calendar)
        self.timeFormatter = DateFormatter(dateFormat: "H:mm", calendar: calendar)
        self.myfunc = myfunc
        
       // print("weekDayFormatter \(CalendarWeekListView().w)")
    }
    
    var body: some View {
        CalendarWeekListView(
            calendar: calendar,
            date: $selectedDate,
            content: { date in
                Button(action: {
                    selectedDate = date
                    withAnimation {
                        //taskModel.currentDay = date
                        print("selectedDate \(selectedDate)")
                    }
                })
                {
           VStack(spacing: 10) {
                        Text("\(dayFormatter.string(from: date))")
                            .font(.system(size: 15))
                            .fontWeight(.semibold)
                        
                        Text(weekDayFormatter.string(from: date))
                            .font(.system(size: 14))
                        Circle()
                            .fill(.white)
                            .frame(width: 8, height: 8)
                            .opacity(calendar.isDate(date, inSameDayAs: selectedDate) ? 1 : 0)
                    }
                    //.foregroundStyle(calendar.isDate(date, inSameDayAs: selectedDate) ? .primary : .secondary)
                    //.foregroundColor(calendar.isDate(date, inSameDayAs: selectedDate) ? .white : .black)
                    .frame(width: 45, height: 90)
                    .background(
                        ZStack {
                          /*  if calendar.isDate(date, inSameDayAs: selectedDate) {
                                Capsule()
                                    //.fill(Color("CardColor2"))
                                    .fill(Color.theme.brandPrimary)
                                    //.border(Color.theme.brandPrimary, width: 1)
                            } */
                        }
                    )
                }
            },
            title: { date in
                HStack {
                    //Text(monthDayFormatter.string(from: selectedDate))
                    Text("\(selectedDate.toString(dateFormat: DateFormat.monthYear))")
                        .font(.headline)
                        .padding(5)
                    Spacer()
                }
                .padding([.bottom, .leading], 10)
            }, weekSwitcher: { date in
                Button {
                    withAnimation(.easeIn) {
                        guard let newDate = calendar.date(
                            byAdding: .weekOfMonth,
                            value: -1,
                            to: selectedDate
                        ) else {
                            return
                        }
                        selectedDate = newDate
                    }
                } label: {
                    Label(
                        title: { Text("Previous") },
                        icon: { Image(systemName: "chevron.left") }
                    )
                        .labelStyle(IconOnlyLabelStyle())
                        .padding(.horizontal)
                }
                Button {
                    withAnimation(.easeIn) {
                        guard let newDate = calendar.date(
                            byAdding: .weekOfMonth,
                            value: 1,
                            to: selectedDate
                        ) else {
                            return
                        }
                        selectedDate = newDate
                        print("weekSwitcher_2 \(selectedDate)")
                    }
                } label: {
                    Label(
                        title: { Text("Next") },
                        icon: { Image(systemName: "chevron.right") }
                    )
                        .labelStyle(IconOnlyLabelStyle())
                        .padding(.horizontal)
                }.disabled(selectedDate > Date.now ? true : false)
            }
        ).onChange(of: selectedDate) { newValue in
           
            guard let firstWeek = calendar.dateInterval(of: .weekOfMonth, for: selectedDate),
                    let lastWeek = calendar.dateInterval(of: .weekOfMonth, for: firstWeek.end - 1)
            else {
                return ;
            }
                
            let dateInterval = DateInterval(start: firstWeek.start, end: lastWeek.end)
            
            myfunc!(calendar.generateDays(for: dateInterval));
            
            //print("weekSwitcher_0 \(calendar.generateDays(for: dateInterval))")
        }
    }
}

//struct CustomCalendarView_Previews: PreviewProvider {
//    static var previews: some View {
//        CustomCalendarView()
//    }
//}
