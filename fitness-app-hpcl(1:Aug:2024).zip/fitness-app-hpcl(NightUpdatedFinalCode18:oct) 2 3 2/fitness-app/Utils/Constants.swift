//
//  Constants.swift
//  fitness-app
//
//  Created by Babu Lal on 24/12/22.
//

import Foundation




struct Constants {
    
    static let appType: String = "I"
    static let appVersion: String = getAppInfo()
    static let dataTypeStepCount: String = "step_count"
    static let dataTypeEnergy: String = "calories"
    static let dataTypeStepMoveMinuteCount: String = "move_minute_count"
    static let dataTypeDistance: String = "distance"
    static let firebaseNotificationId: String = "com.hpcl.fitness"

    
}

func getAppInfo()->String {
    let dictionary = Bundle.main.infoDictionary!
    let version = dictionary["CFBundleShortVersionString"] as! String
    //let build = dictionary["CFBundleVersion"] as! String
   // return version + "(" + build + ")"
    
    return version
}

