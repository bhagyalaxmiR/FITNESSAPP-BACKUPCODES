//
//  GetHealthData.swift
//  fitness-app
//
//  Created by Babu Lal on 14/12/22.
//

import Foundation
import HealthKit

enum DataType {
    case distance
    case steps
    case energy
    case heartpoints
    
    var sampleType: HKSampleType? {
        switch self {
        case .steps:
            return HKQuantityType.quantityType(forIdentifier: .stepCount)
        case .distance:
            return HKQuantityType.quantityType(forIdentifier: .distanceWalkingRunning)
        case .energy:
            return HKQuantityType.quantityType(forIdentifier: .activeEnergyBurned)
        case .heartpoints:
            return HKQuantityType.quantityType(forIdentifier: .heartRate)
        }
    }
}

class GetHealthData {
    
    let predicate = NSPredicate(format: "metadata.%K != YES", HKMetadataKeyWasUserEntered)
    func isManuallyEntered(_ sample: HKQuantitySample) -> Bool {
           if let metadata = sample.metadata,
              let wasUserEntered = metadata[HKMetadataKeyWasUserEntered] as? Bool,
              wasUserEntered {
               return true // The data was manually entered
           }
           return false // The data was likely not manually entered
       }
    fileprivate lazy var healthKitManager: HealthKitManager = {
        let manager = HealthKitManager()
        return manager
    }()
    
    func getSample(date: Date, sampleType: HKQuantityTypeIdentifier) -> HKQuantitySample? {
      //  let predicate = HKQuery.predicateForSamples(withStart: date, end: date, options: .strictStartDate)
       
        
        let predicate = NSPredicate(format: "metadata.%K != YES", HKMetadataKeyWasUserEntered)
        
        let sampleType = HKObjectType.quantityType(forIdentifier: sampleType)
       
        let query = HKSampleQuery(
            sampleType: sampleType!,
            predicate: predicate,
            limit: HKObjectQueryNoLimit,
            sortDescriptors: nil
        ){ (query, results, error) in
            if results?.first is HKQuantitySample {
                // Do something with the sample if needed
            }
        }
        
        HKHealthStore().execute(query)
        // You may want to return nil here and handle the asynchronous result in your code.
        return nil
    }

    func fetchDataFor(numberOfDays: Int, dataType: DataType, completion: @escaping CompletionHandler) {
        // TO FETCH TODAYS DATA, KEEP numberOfDays = 1
        
        let endDate = Date()
        guard let startDate = endDate.getDateFromNow(whenDifferenceInDays: numberOfDays) else {
            return
        }
    
        switch dataType {
        case .distance:
            
//            healthKitManager.getDistance(From: startDate, To: endDate) { (response, error) in
//                if let response = response {
//                    // Filter out manually entered data
//                    let filteredResponse = response.filter { (dataPoint) in
//                        if let sample = self.getSample(date: dataPoint.keys.first!, sampleType: .distanceWalkingRunning) {
//                            return !self.isManuallyEntered(sample)
//                        }
//                        return false
//                    }
//                    // Convert the filtered array to the expected format
//                    let dataArray = filteredResponse.map { $0 }
//                    completion(dataArray, nil) // Pass nil for the error
//                } else {
//                    completion([], error) // Handle the error case accordingly
//                }
//            }
            
            healthKitManager.getDistance(From: startDate, To: endDate) { (response, error) in
                var filteredResponse: [[Date: Double]] = []

                if let response = response {
                    // Filter out manually entered data
                    filteredResponse = response.filter { (dataPoint) in
                        if let sample = self.getSample(date: dataPoint.keys.first!, sampleType: .distanceWalkingRunning) {
                            print("Distance : SAMPLE",sample)
                            print("Distance : SAMPLE-111",filteredResponse)
                            return !self.isManuallyEntered(sample)
                        }
                        return filteredResponse == [[Date: Double]](repeating: [Date(): 0.0], count: 1)
                    }
                } else {
                    // Handle the case when response is nil by assigning an array with a single data point of 0.0
                    filteredResponse = [[Date: Double]](repeating: [Date(): 0.0], count: 4)
                   
                }
                if filteredResponse == [] {
                    filteredResponse.append([Date(): 0.0])
                }
                completion(filteredResponse, error)
                print("Distance : FILTER-RESPONSE",filteredResponse)
               // print("FILTER-RESPONSE",response)
               completion(response,error)
            }
  
        case .steps:
            healthKitManager.getSteps(From: startDate, To: endDate) { (response, error) in
                var filteredResponse: [[Date: Double]] = []

                if let response = response {
                    // Filter out manually entered data
                    filteredResponse = response.filter { (dataPoint) in
                        if let sample = self.getSample(date: dataPoint.keys.first!, sampleType: .stepCount) {
                            print("Steps : SAMPLE",sample)
                            print("Steps : SAMPLE",filteredResponse)
                            return !self.isManuallyEntered(sample)
                        }
                        return filteredResponse == [[Date: Double]](repeating: [Date(): 0.0], count: 1)
                    }
                } else {
                    // Handle the case when response is nil by assigning an array with a single data point of 0.0
                    filteredResponse = [[Date: Double]](repeating: [Date(): 0.0], count: 1)
                }
                if filteredResponse == [] {
                    filteredResponse.append([Date(): 0.0])
                }

                completion(filteredResponse, error)
                print("Steps : FILTERRESPONSE",filteredResponse)
                //print("FILTERRESPONSE",response)
                completion(response,error)
               
            }

//            healthKitManager.getSteps(From: startDate, To: endDate) { (response, error) in
//                if let response = response {
//                    // Filter out manually entered data and replace it with 0
//                    var filteredResponse: [[Date: Double]] = []
//                    
//                    for dataPoint in response {
//                        if let sample = self.getSample(date: dataPoint.keys.first!, sampleType: .stepCount) {
//                            if !self.isManuallyEntered(sample) {
//                                filteredResponse.append(dataPoint)
//                            } else {
//                                let date = dataPoint.keys.first!
//                                let replacedDataPoint: [Date: Double] = [date: 0.0]
//                                filteredResponse.append(replacedDataPoint)
//                            }
//                        }
//                    }
//                    
//                    completion(filteredResponse, nil) // Pass nil for the error
//                } else {
//                    // No data to filter, so assign an empty array and handle the error case accordingly
//                    let dataArray: [[Date: Double]] = []
//                    completion(dataArray, nil) // Pass nil for the error
//                }
//           completion(response,error)
//            }
            
        case .energy:
//            healthKitManager.getEnergy(From: startDate, To: endDate) { (response, error) in
//                if let response = response {
//                    // Filter out manually entered data
//                    let filteredResponse = response.filter { (dataPoint) in
//                        if let sample = self.getSample(date: dataPoint.keys.first!, sampleType: .activeEnergyBurned) {
//                            return !self.isManuallyEntered(sample)
//                        }
//                        return false
//                    }
//                    
//                    // Convert the filtered array to the expected format
//                    let dataArray = filteredResponse.map { $0 }
//                    completion(dataArray, nil) // Pass nil for the error
//                } else {
//                    completion([], error) // Handle the error case accordingly
//                }
//            }
            
            healthKitManager.getEnergy(From: startDate, To: endDate) { (response, error) in
                var filteredResponse: [[Date: Double]] = []

                if let response = response {
                    // Filter out manually entered data
                    filteredResponse = response.filter { (dataPoint) in
                        if let sample = self.getSample(date: dataPoint.keys.first!, sampleType: .activeEnergyBurned) {
                            print("Energy : SAMPLE",sample)
                            print("Energy : SAMPLE",filteredResponse)
                            return !self.isManuallyEntered(sample)
                        }
                        return filteredResponse == [[Date: Double]](repeating: [Date(): 0.0], count: 1)
                    }
                } else {
// Handle the case when response is nil by assigning an array with a single data point of 0.0
                    filteredResponse = [[Date: Double]](repeating: [Date(): 0.0], count: 1)
                }
                if filteredResponse == [] {
                    filteredResponse.append([Date(): 0.0])
                }

                completion(filteredResponse, error)
                print("Energy : FILTERRESPONSE",filteredResponse)
                //print("Steps : FILTERRESPONSE",response)
               // completion(response,error)
            }
            
        case .heartpoints:
            healthKitManager.getEnergy(From: startDate, To: endDate) { (response, error) in
                if let response = response {
                    // Filter out manually entered data
                    let filteredResponse = response.filter { (dataPoint) in
                        if let sample = self.getSample(date: dataPoint.keys.first!, sampleType: .heartRate) { // Modify this according to your data structure
                            return !self.isManuallyEntered(sample)
                        }
                        return false
                    }
                    // Convert the filtered array to the expected format
                    let dataArray = filteredResponse.map { $0 }
                    completion(dataArray, nil) // Pass nil for the error
                } else {
                    completion([], error) // Handle the error case accordingly
                }
            }
        }
    }
    
    
    func fetchDataForNoOfDays(numberOfDays:Int, dataType: DataType, completion: @escaping CompletionHandler) {
        
        // TO FETCH TODAYS DATA, KEEP numberOfDays = 1
        
//        var endDate = Date()
//        guard var startDate = endDate.getDateFromNow(whenDifferenceInDays: 1) else {
//            return
//        }
        
        
        var endDate = Date()
        guard var startDate = endDate.getDateFromNow(whenDifferenceInDays: numberOfDays) else {
            return
        }
        
        
        
//        if(startDateValue != nil){
//            
//            startDate = startDateValue!
//            endDate = endDateValue!.endOfDay(startOfDay: endDateValue!)
//            print ("startDateValue \(String(describing: startDate))")
//            print ("endDateValue \(String(describing: endDate))")
//        }
        
//        let endDate = Date()
//        let startDate = Date()
        switch dataType {
        case .distance:
//            healthKitManager.getDistance(From: startDate, To: endDate) { (response, error) in
//                completion(response, error)
//            }
            
            healthKitManager.getDistance(From: startDate, To: endDate) { (response, error) in
                if let response = response {
                    // Filter out manually entered data and replace it with 0
                    var filteredResponse: [[Date: Double]] = []
                    
                    for dataPoint in response {
                        if let sample = self.getSample(date: dataPoint.keys.first!, sampleType: .distanceWalkingRunning) {
                            if !self.isManuallyEntered(sample) {
                                filteredResponse.append(dataPoint)
                            } else {
                                let date = dataPoint.keys.first!
                                let replacedDataPoint: [Date: Double] = [date: 0.0]
                                filteredResponse.append(replacedDataPoint)
                            }
                        }
                    }
                    
                    // Sort the filtered data points by date in ascending order
                    filteredResponse.sort { (point1, point2) in
                        return point1.keys.first! < point2.keys.first!
                    }
                    
                    completion(filteredResponse, nil) // Pass nil for the error
                } else {
                    // No data to filter, so assign an empty array and handle the error case accordingly
                    let dataArray: [[Date: Double]] = []
                    completion(dataArray, nil) // Pass nil for the error
                }
                completion(response,error)
            }
            
        case .steps:
            healthKitManager.getSteps(From: startDate, To: endDate) { (response, error) in
                if let response = response {
                    // Filter out manually entered data and replace it with 0
                    var filteredResponse: [[Date: Double]] = []
                    
                    for dataPoint in response {
                        if let sample = self.getSample(date: dataPoint.keys.first!, sampleType: .stepCount) {
                            if !self.isManuallyEntered(sample) {
                                filteredResponse.append(dataPoint)
                            } else {
                                let date = dataPoint.keys.first!
                                let replacedDataPoint: [Date: Double] = [date: 0.0]
                                filteredResponse.append(replacedDataPoint)
                            }
                        }
                    }
                    
                    // Sort the filtered data points by date in ascending order
                    filteredResponse.sort { (point1, point2) in
                        return point1.keys.first! < point2.keys.first!
                    }
                    
                    completion(filteredResponse, nil) // Pass nil for the error
                } else {
                    // No data to filter, so assign an empty array and handle the error case accordingly
                    let dataArray: [[Date: Double]] = []
                    completion(dataArray, nil) // Pass nil for the error
                }
                completion(response,error)
            }
        case .energy:
            healthKitManager.getEnergy(From: startDate, To: endDate) { (response, error) in
                if let response = response {
                    // Filter out manually entered data and replace it with 0
                    var filteredResponse: [[Date: Double]] = []
                    
                    for dataPoint in response {
                        if let sample = self.getSample(date: dataPoint.keys.first!, sampleType: .activeEnergyBurned) {
                            if !self.isManuallyEntered(sample) {
                                filteredResponse.append(dataPoint)
                            }else {
                                let date = dataPoint.keys.first!
                                let replacedDataPoint: [Date: Double] = [date: 0.0]
                                filteredResponse.append(replacedDataPoint)
                            }
                        }
                    }
                    // Sort the filtered data points by date in ascending order
                    filteredResponse.sort { (point1, point2) in
                        return point1.keys.first! < point2.keys.first!
                    }
                    
                    completion(filteredResponse, nil) // Pass nil for the error
                } else {
                    // No data to filter, so assign an empty array and handle the error case accordingly
                    let dataArray: [[Date: Double]] = []
                    completion(dataArray, nil) // Pass nil for the error
                }
                completion(response,error)
            }
        case .heartpoints:
//            healthKitManager.getEnergy(From: startDate, To: endDate) { (response, error) in
//                completion(response, error)
//            }
            healthKitManager.getEnergy(From: startDate, To: endDate) { (response, error) in
                if let response = response {
                    // Filter out manually entered data and replace it with 0
                    var filteredResponse: [[Date: Double]] = []
                    for dataPoint in response {
                        if let sample = self.getSample(date: dataPoint.keys.first!, sampleType: .heartRate) {
                            if !self.isManuallyEntered(sample) {
                                filteredResponse.append(dataPoint)
                            } else {
                                let date = dataPoint.keys.first!
                                let replacedDataPoint: [Date: Double] = [date: 0.0]
                                filteredResponse.append(replacedDataPoint)
                               }
                        }
                    }
                    // Sort the filtered data points by date in ascending order
                    filteredResponse.sort { (point1, point2) in
                        return point1.keys.first! < point2.keys.first!
                    }
                    completion(filteredResponse, nil) // Pass nil for the error
                } else {
                    // No data to filter, so assign an empty array and handle the error case accordingly
                    let dataArray: [[Date: Double]] = []
                    completion(dataArray, nil) // Pass nil for the error
                }
                completion(response,error)
            }
        }
    }
       
    func fetchDataForCustomDate(dataType: DataType,startDateValue:Date?, endDateValue:Date?, completion: @escaping CompletionHandler) {
        
        // TO FETCH TODAYS DATA, KEEP numberOfDays = 1
        
        var endDate = Date()
        guard var startDate = endDate.getDateFromNow(whenDifferenceInDays: 1) else {
            return
        }
        
        
//        var endDate = Date()
//        guard var startDate = endDate.getDateFromNow(whenDifferenceInDays: numberOfDays) else {
//            return
//        }
        
        
        
        if(startDateValue != nil){
            
            startDate = startDateValue!
            endDate = endDateValue!.endOfDay(startOfDay: endDateValue!)
            print ("startDateValue \(String(describing: startDate))")
            print ("endDateValue \(String(describing: endDate))")
        }
        
//        let endDate = Date()
//        let startDate = Date()
        switch dataType {
        case .distance:
//            healthKitManager.getDistance(From: startDate, To: endDate) { (response, error) in
//                completion(response, error)
//            }
            
            healthKitManager.getDistance(From: startDate, To: endDate) { (response, error) in
                if let response = response {
                    // Filter out manually entered data and replace it with 0
                    var filteredResponse: [[Date: Double]] = []
                    
                    for dataPoint in response {
                        if let sample = self.getSample(date: dataPoint.keys.first!, sampleType: .distanceWalkingRunning) {
                            if !self.isManuallyEntered(sample) {
                                filteredResponse.append(dataPoint)
                            } else {
                                let date = dataPoint.keys.first!
                                let replacedDataPoint: [Date: Double] = [date: 0.0]
                                filteredResponse.append(replacedDataPoint)
                            }
                        }
                    }
                    
                    // Sort the filtered data points by date in ascending order
                    filteredResponse.sort { (point1, point2) in
                        return point1.keys.first! < point2.keys.first!
                    }
                    
                    completion(filteredResponse, nil) // Pass nil for the error
                } else {
                    // No data to filter, so assign an empty array and handle the error case accordingly
                    let dataArray: [[Date: Double]] = []
                    completion(dataArray, nil) // Pass nil for the error
                }
                completion(response,error)
            }
            
        case .steps:
            healthKitManager.getSteps(From: startDate, To: endDate) { (response, error) in
                if let response = response {
                    // Filter out manually entered data and replace it with 0
                    var filteredResponse: [[Date: Double]] = []
                    
                    for dataPoint in response {
                        if let sample = self.getSample(date: dataPoint.keys.first!, sampleType: .stepCount) {
                            if !self.isManuallyEntered(sample) {
                                filteredResponse.append(dataPoint)
                            } else {
                                let date = dataPoint.keys.first!
                                let replacedDataPoint: [Date: Double] = [date: 0.0]
                                filteredResponse.append(replacedDataPoint)
                            }
                        }
                    }
                    
                    // Sort the filtered data points by date in ascending order
                    filteredResponse.sort { (point1, point2) in
                        return point1.keys.first! < point2.keys.first!
                    }
                    
                    completion(filteredResponse, nil) // Pass nil for the error
                } else {
                    // No data to filter, so assign an empty array and handle the error case accordingly
                    let dataArray: [[Date: Double]] = []
                    completion(dataArray, nil) // Pass nil for the error
                }
                completion(response,error)
            }
        case .energy:
            healthKitManager.getEnergy(From: startDate, To: endDate) { (response, error) in
                if let response = response {
                    // Filter out manually entered data and replace it with 0
                    var filteredResponse: [[Date: Double]] = []
                    
                    for dataPoint in response {
                        if let sample = self.getSample(date: dataPoint.keys.first!, sampleType: .activeEnergyBurned) {
                            if !self.isManuallyEntered(sample) {
                                filteredResponse.append(dataPoint)
                            }else {
                                let date = dataPoint.keys.first!
                                let replacedDataPoint: [Date: Double] = [date: 0.0]
                                filteredResponse.append(replacedDataPoint)
                            }
                        }
                    }
                    // Sort the filtered data points by date in ascending order
                    filteredResponse.sort { (point1, point2) in
                        return point1.keys.first! < point2.keys.first!
                    }
                    
                    completion(filteredResponse, nil) // Pass nil for the error
                } else {
                    // No data to filter, so assign an empty array and handle the error case accordingly
                    let dataArray: [[Date: Double]] = []
                    completion(dataArray, nil) // Pass nil for the error
                }
                completion(response,error)
            }
        case .heartpoints:
//            healthKitManager.getEnergy(From: startDate, To: endDate) { (response, error) in
//                completion(response, error)
//            }
            healthKitManager.getEnergy(From: startDate, To: endDate) { (response, error) in
                if let response = response {
                    // Filter out manually entered data and replace it with 0
                    var filteredResponse: [[Date: Double]] = []
                    for dataPoint in response {
                        if let sample = self.getSample(date: dataPoint.keys.first!, sampleType: .heartRate) {
                            if !self.isManuallyEntered(sample) {
                                filteredResponse.append(dataPoint)
                            } else {
                                let date = dataPoint.keys.first!
                                let replacedDataPoint: [Date: Double] = [date: 0.0]
                                filteredResponse.append(replacedDataPoint)
                               }
                        }
                    }
                    // Sort the filtered data points by date in ascending order
                    filteredResponse.sort { (point1, point2) in
                        return point1.keys.first! < point2.keys.first!
                    }
                    completion(filteredResponse, nil) // Pass nil for the error
                } else {
                    // No data to filter, so assign an empty array and handle the error case accordingly
                    let dataArray: [[Date: Double]] = []
                    completion(dataArray, nil) // Pass nil for the error
                }
                completion(response,error)
            }
        }
    }
}
extension Array where Element: Equatable {
    var removeDuplicate: [Element] {
        return reduce([]) { $0.contains($1) ? $0 : $0 + [$1] }
    }
}
