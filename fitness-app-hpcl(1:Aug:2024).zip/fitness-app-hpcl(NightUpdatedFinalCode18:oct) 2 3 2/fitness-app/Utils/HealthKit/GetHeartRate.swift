//
//  GetHeartRate.swift
//  fitness-app
//
//  Created by Babu Lal on 15/12/22.
//

import Foundation
import SwiftUI
import HealthKit
class GetHeartRate {
    let healthStore = HKHealthStore()
    var dateHelper = DateHelper()
    
    @State private var value = 0
    let heartRateQuantity = HKUnit(from: "count/min")
    
    
    func autorizeHealthKit() {
        print("getHeartRate 1");
        let healthKitTypes: Set = [
            HKObjectType.quantityType(forIdentifier: HKQuantityTypeIdentifier.heartRate)!]
        
        healthStore.requestAuthorization(toShare: healthKitTypes, read: healthKitTypes) { _, _ in }
    }
    func isManuallyEntered(_ sample: HKQuantitySample) -> Bool {
           if let metadata = sample.metadata,
              let wasUserEntered = metadata[HKMetadataKeyWasUserEntered] as? Bool,
              wasUserEntered {
               return true // The data was manually entered
           }
           return false // The data was likely not manually entered
       }
    
    
    public func fetchLatestHeartRateSample(
        completion : @escaping (Bool?, Int?, String?) -> Void) {

        /// Create sample type for the heart rate
        guard let sampleType = HKObjectType
          .quantityType(forIdentifier: .heartRate) else {
            completion(false, 0,"Heart Rate Permission not enable")
          return
        }
            

        /// Predicate for specifiying start and end dates for the query
            

        let predicate = HKQuery
          .predicateForSamples(
           // withStart: Date.distantPast,
            withStart: Date().previousNextDate(value: -1),
            end: Date(),
            options: .strictEndDate)

        /// Set sorting by date.
        let sortDescriptor = NSSortDescriptor(
          key: HKSampleSortIdentifierStartDate,
          ascending: false)

        /// Create the query
        let query = HKSampleQuery(
          sampleType: sampleType,
          predicate: predicate,
          limit: Int(HKObjectQueryNoLimit),
          sortDescriptors: [sortDescriptor]) { (_, results, error) in

            guard error == nil else {
              //print("Error: \(error!.localizedDescription)")
                completion(false, 0,error!.localizedDescription)
              return
            }

            //  self.process(results as? [HKQuantitySample], type: HKQuantityTypeIdentifier.heartRate)
              
              
              self.process( results as? [HKQuantitySample], type: HKQuantityTypeIdentifier.heartRate, completion: { (success, heartRate, error) in
                  
                  if(success == true){
                      
                      completion(true, heartRate,error)
                   
                      
                  }else {
                      completion(false, 0,error)

                  }
               

              })
            //completion(results as? [HKQuantitySample])
        }

        /// Execute the query in the health store
        let healthStore = HKHealthStore()
        healthStore.execute(query)
      }
   
    func process(_ samples: [HKQuantitySample]?, type: HKQuantityTypeIdentifier, completion : @escaping (Bool?, Int?, String?) -> Void) {
       var lastHeartRate = 0.0
       // print("getHeartRate 3");
       
       for sample in samples! {
           if type == .heartRate {
               lastHeartRate = sample.quantity.doubleValue(for: heartRateQuantity)
           }
           
          
           //var value = Int(lastHeartRate)
           
           completion(true, Int(lastHeartRate),"")

           
           //print("HeartRateValue \(value)");
       }
   }
}
