//
//  UserDefaults.swift
//  fitness-app
//
//  Created by Babu Lal on 21/12/22.
//

import Foundation
import Foundation

extension UserDefaults {
    
    enum Keys: String, CaseIterable {
        
        case loginStatusKey
        case nameKey
        case emailKey
        case tokenKey
        case mobileKey
        case stepsADayKey
        case heartPointADayKey
        case isHeartPointKey
        case isCaloriesKey
        case isDistanceKey
        case isMoveMinuteKey
        case isPreferencesKey
        case pushNotificationFirebaseTokenKey
        case pmeKey
        case leaderboardkey
        case empNokey
        case lastsevendaystepcountkey

    }
    
    func reset() {
        Keys.allCases.forEach { removeObject(forKey: $0.rawValue) }
    }
    
    var loginStatus: Bool {
        set {
            UserDefaults.standard.set(newValue, forKey: UserDefaults.Keys.loginStatusKey.rawValue)
        }
        get {
            return UserDefaults.standard.bool(forKey: UserDefaults.Keys.loginStatusKey.rawValue)
        }
    }
    
    var name: String? {
        set {
            UserDefaults.standard.set(newValue, forKey: UserDefaults.Keys.nameKey.rawValue)
        }
        get {
            return UserDefaults.standard.string(forKey: UserDefaults.Keys.nameKey.rawValue)
        }
    }
    
    var email: String? {
        set {
            UserDefaults.standard.set(newValue, forKey: UserDefaults.Keys.emailKey.rawValue)
        }
        get {
            return UserDefaults.standard.string(forKey: UserDefaults.Keys.emailKey.rawValue)
        }
    }
    
    var token: String? {
        set {
            UserDefaults.standard.set(newValue, forKey: UserDefaults.Keys.tokenKey.rawValue)
        }
        get {
            return UserDefaults.standard.string(forKey: UserDefaults.Keys.tokenKey.rawValue)
        }
    }
    
    var mobile: String? {
        set {
            UserDefaults.standard.set(newValue, forKey: UserDefaults.Keys.mobileKey.rawValue)
        }
        get {
            return UserDefaults.standard.string(forKey: UserDefaults.Keys.mobileKey.rawValue)
        }
    }
    
    var stepsADay: String? {
        set {
            UserDefaults.standard.set(newValue ?? "5000", forKey: UserDefaults.Keys.stepsADayKey.rawValue)
        }
        get {
            return UserDefaults.standard.string(forKey: UserDefaults.Keys.stepsADayKey.rawValue) ?? "5000"
        }
    }
    
    var heartPointADay: String? {
        set {
            UserDefaults.standard.set(newValue ?? "40", forKey: UserDefaults.Keys.heartPointADayKey.rawValue)
        }
        get {
            return UserDefaults.standard.string(forKey: UserDefaults.Keys.heartPointADayKey.rawValue) ?? "40"
        }
    }
    
    var isHeartPoint:Bool {
        set {
            UserDefaults.standard.set(newValue, forKey: UserDefaults.Keys.isHeartPointKey.rawValue)
        }
        get {
            return UserDefaults.standard.bool(forKey: UserDefaults.Keys.isHeartPointKey.rawValue)
        }
    }
    
    var isCalories: Bool {
        set {
            UserDefaults.standard.set(newValue , forKey: UserDefaults.Keys.isCaloriesKey.rawValue)
        }
        get {
            return UserDefaults.standard.bool(forKey: UserDefaults.Keys.isCaloriesKey.rawValue)
        }
    }
    
    var isDistance: Bool {
        set {
            UserDefaults.standard.set(newValue , forKey: UserDefaults.Keys.isDistanceKey.rawValue)
        }
        get {
            return UserDefaults.standard.bool(forKey: UserDefaults.Keys.isDistanceKey.rawValue)
        }
    }
    
    var isMoveMinute: Bool {
        set {
            UserDefaults.standard.set(newValue , forKey: UserDefaults.Keys.isMoveMinuteKey.rawValue)
        }
        get {
            return UserDefaults.standard.bool(forKey: UserDefaults.Keys.isMoveMinuteKey.rawValue)
        }
    }
    
    var isPreferences: Bool {
        set {
            UserDefaults.standard.set(newValue , forKey: UserDefaults.Keys.isPreferencesKey.rawValue)
        }
        get {
            return UserDefaults.standard.bool(forKey: UserDefaults.Keys.isPreferencesKey.rawValue)
        }
    }
    
    var pushNotificationFirebaseToken: String? {
        set {
            UserDefaults.standard.set(newValue, forKey: UserDefaults.Keys.pushNotificationFirebaseTokenKey.rawValue)
        }
        get {
            return UserDefaults.standard.string(forKey: UserDefaults.Keys.pushNotificationFirebaseTokenKey.rawValue)
        }
    }
    
    var empNo: String? {
        set {
            UserDefaults.standard.set(newValue, forKey: UserDefaults.Keys.empNokey.rawValue)
        }
        get {
            return UserDefaults.standard.string(forKey: UserDefaults.Keys.empNokey.rawValue)
        }
    }
    
   
    
    var pme: Bool {
        set {
            UserDefaults.standard.set(newValue , forKey: UserDefaults.Keys.pmeKey.rawValue)
        }
        get {
            return UserDefaults.standard.bool(forKey: UserDefaults.Keys.pmeKey.rawValue)
        }
    }
    
//    var leaderboard: Bool {
//        set {
//            UserDefaults.standard.set(newValue , forKey: UserDefaults.Keys.leaderboardkey.rawValue)
//
//        }
//        get {
//            return UserDefaults.standard.bool(forKey: UserDefaults.Keys.pmeKey.rawValue)
//        }
//    }
    
    var lastsevendaysstepcount: Bool {
        set {
            UserDefaults.standard.set(newValue , forKey:UserDefaults.Keys.pmeKey.rawValue)
        }
        get {
            return UserDefaults.standard.bool(forKey: UserDefaults.Keys.pmeKey.rawValue)
        }
    }
    
}

// Write/Set Boolean in User Defaults
//UserDefaults.standard.set(true, forKey: UserDefaults.Keys.allowDownloadsOverCellular.rawValue)

//print("before", UserDefaults.standard.bool(forKey: UserDefaults.Keys.allowDownloadsOverCellular.rawValue))

// Reset User Defaults
//UserDefaults.standard.reset()

//print("after", UserDefaults.standard.bool(forKey: UserDefaults.Keys.allowDownloadsOverCellular.rawValue))
