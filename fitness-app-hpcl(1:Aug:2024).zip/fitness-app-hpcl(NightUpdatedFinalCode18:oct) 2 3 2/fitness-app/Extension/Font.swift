//
//  Font.swift
//  fitness-app
//
//  Created by Babu Lal on 13/12/22.
//

import Foundation
import SwiftUI

extension Font {
    
    static let theme = FontTheme();
    
}

struct FontTheme{
    
    let headlineBig = Font.custom("Arial", size: 40).weight(Font.Weight.heavy)
    let headline = Font.custom("Arial", size: 35).weight(Font.Weight.bold)
    let title = Font.custom("Arial", size: 22).weight(Font.Weight.bold)
    let subTitle = Font.custom("Arial", size: 20)
    let body = Font.custom("Arial", size: 16)
    let subBody = Font.custom("Arial", size: 12)
    let button = Font.custom("Arial", size: 16)
    let warning = Font.custom("Arial", size: 8)
    let toolbar = Font.custom("Arial", size: 20).weight(Font.Weight.light)
    let navTitle = Font.custom("Arial", size: 20).weight(Font.Weight.bold)

}
