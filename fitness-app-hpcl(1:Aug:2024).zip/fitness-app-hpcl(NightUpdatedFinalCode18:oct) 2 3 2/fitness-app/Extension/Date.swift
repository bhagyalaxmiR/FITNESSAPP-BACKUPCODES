//
//  Date.swift
//  fitness-app
//
//  Created by Babu Lal on 14/12/22.
//

import Foundation
import Foundation

struct DateFormat {
    static let local: String = "yyyy-MM-dd"
    static let dayWise: String = "EEE"
    static let dateWise: String = "dd"
    static let monthYear: String = "MMM/yyyy"
    static let localDateTime: String = "yyyy-MM-dd HH:mm:ss +0000"

}

//extension String {
//    func toDate(withFormat format: String = "yyyy-MM-dd") -> Date {
//       let dateFormatter = DateFormatter()
//       dateFormatter.dateFormat = format
//       guard let date = dateFormatter.date(from: self) else {
//         preconditionFailure("Take a look to your format")
//       }
//       return date
//     }
//}
extension String {
    func toDate(dateFormat format  : String) -> Date?
    {
//        let formatter4 = DateFormatter()
//        formatter4.dateFormat = format
//        formatter4.timeZone = TimeZone(abbreviation: "UTC")
//        return   formatter4.string(from: self)
        
        
       // let dateString = "January 20, 2020"
        let dateFormatter = DateFormatter()
        //dateFormatter.locale = Locale(identifier: "en_US_POSIX")
        dateFormatter.timeZone = TimeZone(abbreviation: "IST")
        dateFormatter.dateFormat = format
        return  dateFormatter.date(from:self)
        
        
//        let dateFormatter = DateFormatter()
//        dateFormatter.dateFormat = format
//        dateFormatter.timeZone = TimeZone(abbreviation: "UTC")
//        return dateFormatter.date(from: self)
    }
}

extension Date {
    
    var currentDate: Date {
        
        return Date();
    }
    
    static var yesterday: Date { return Date().dayBefore }

    var dayBefore: Date {
            return Calendar.current.date(byAdding: .day, value: -1, to: noon)!
        }
    
    var dayAfter: Date {
            return Calendar.current.date(byAdding: .day, value: 1, to: noon)!
        }
    
    
    
  /*  var startOfDay : Date {
        let calendar = Calendar.current
        let unitFlags = Set<Calendar.Component>([.year, .month, .day])
        let components = calendar.dateComponents(unitFlags, from: self)
        return calendar.date(from: components)!
    }
    
    var endOfDay : Date {
        var components = DateComponents()
        components.day = 1
        let date = Calendar.current.date(byAdding: components, to: self.startOfDay)
        return (date?.addingTimeInterval(-1))!
    }   */
    
    func startOfDay(value : Date) -> Date {
        let calendar = Calendar.current
        let unitFlags = Set<Calendar.Component>([.year, .month, .day])
        let components = calendar.dateComponents(unitFlags, from: self)
        return calendar.date(from: components)!
    }
    
    func endOfDay(startOfDay : Date) -> Date {
        var components = DateComponents()
        components.day = 1
        let date = Calendar.current.date(byAdding: components, to: startOfDay)
        return (date?.addingTimeInterval(-1))!
    }
    
  /*  var endOfDay: Date {
            var components = DateComponents()
            components.day = 1
            components.second = -1
            return Calendar.current.date(byAdding: components, to: startOfDay)!
        }
    
    var startOfDay: Date {
           return Calendar.current.startOfDay(for: self)
       } */
    
    
    
    var noon: Date {
        return Calendar.current.date(bySettingHour: 12, minute: 0, second: 0, of: self)!
    }
    
    func previousNextDate(value : Int) -> Date {
        //let startOfDay = Calendar.current.startOfDay(for: value)
        
        
        return Calendar.current.date(byAdding: .day, value: value, to: noon)!;
    }
    
    func getFormattedDate(format: String) -> Date? {
        let dateformat = DateFormatter()
        dateformat.dateFormat = format
        let date = dateformat.date(from: String(describing: Date()));
        
        return date;
    }
    
    
    
    func toString( dateFormat format  : String ) -> String
    {
//        let dateFormatter = DateFormatter()
//        dateFormatter.dateFormat = format
//        return dateFormatter.string(from: self)
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = format
        dateFormatter.timeZone = TimeZone(abbreviation: "UTC")
        return dateFormatter.string(from: self)
    }
    
   
    
    var stringValue: String {
      let dateFormatter = DateFormatter()
      dateFormatter.dateFormat = "yyyy-MM-dd"
      dateFormatter.timeZone = TimeZone(abbreviation: "UTC")
      return dateFormatter.string(from: self)
    }
    
  /*
  THIS METHOD WILL SUBTRACT THE days FROM THE CURRENT DATE AND RETURNS THE DATE AS AS START DATE
  EX - SUPPOSE TODAYS DATE IS 27/11/19 AND days = 2
  SO IT WILL RETURN 25/11/19 AS START DATE.
  */
    
    func getDateFromNow(whenDifferenceInDays days: Int) -> Date? {
      let calendar = Calendar.current
      
      guard let date = calendar.date(byAdding: .day, value: -(days - 1), to: self) else {
        return nil
      }
      return calendar.startOfDay(for: date)
    }
    
    
}
