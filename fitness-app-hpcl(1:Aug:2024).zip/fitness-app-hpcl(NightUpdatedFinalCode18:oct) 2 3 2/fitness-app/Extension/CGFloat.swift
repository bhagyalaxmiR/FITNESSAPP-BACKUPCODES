//
//  CGFloat.swift
//  fitness-app
//
//  Created by Babu Lal on 13/12/22.
//

import Foundation
import SwiftUI

extension CGFloat {
    
    static let theme = CGFloatTheme();
    
}

struct CGFloatTheme{
    
    let extraLargeSpacing:CGFloat = 32.0
    let largeSpacing:CGFloat  = 16.0
    let  mediumSpacing:CGFloat = 12.0
    let smallSpacing:CGFloat = 8.0
    let extraSmallSpacing:CGFloat = 4.0
    
    let cornerRadius:CGFloat = 12.0
    
    let lineWidth:CGFloat = 0.9
    
    let logoHeight:CGFloat = 150.0
    let logoWidth:CGFloat = 150.0

    let menuWidth:CGFloat = 270.0


    let menuItemOpacity:CGFloat = 0.4

    let textFieldSpacing:CGFloat = 10.0
    
    let circleBorderWidth:CGFloat = 10.0
    let dashboardIconSize:CGFloat = 16.0

    let formTopSpacing:CGFloat = -18.0
    
    let zero:CGFloat = 0.0


}
